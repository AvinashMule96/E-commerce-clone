import React, { createContext, useContext, useState, useEffect } from 'react';

const CartContext = createContext();

const CART_STORAGE_KEY = 'ecommerce_cart_items';
const COUPON_STORAGE_KEY = 'ecommerce_applied_coupon';

// Initial default cart matching Figma design precisely:
// Casual Cotton Shirt ($29.99) + Running Shoes ($59.99) = $89.98 Subtotal + $5.40 Tax (6%) = $95.38 Total
const DEFAULT_INITIAL_CART = [
  {
    id: 'cart-item-1',
    productId: 'prod-1',
    name: 'Casual Cotton Shirt',
    slug: 'casual-cotton-shirt',
    category: 'men',
    price: 29.99,
    size: 'M',
    color: 'Olive Green',
    colorHex: '#556b2f',
    quantity: 1,
    image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80'
  },
  {
    id: 'cart-item-2',
    productId: 'prod-2',
    name: 'Running Shoes',
    slug: 'running-shoes',
    category: 'footwear',
    price: 59.99,
    size: '9',
    color: 'Black',
    colorHex: '#111827',
    quantity: 1,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80'
  }
];

export const CartProvider = ({ children }) => {
  const [cartItems, setCartItems] = useState(() => {
    try {
      const saved = localStorage.getItem(CART_STORAGE_KEY);
      if (saved) {
        return JSON.parse(saved);
      }
      return DEFAULT_INITIAL_CART;
    } catch (e) {
      return DEFAULT_INITIAL_CART;
    }
  });

  const [appliedCoupon, setAppliedCoupon] = useState(() => {
    try {
      const saved = localStorage.getItem(COUPON_STORAGE_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(CART_STORAGE_KEY, JSON.stringify(cartItems));
    } catch (e) {
      console.error('Error saving cart to localStorage', e);
    }
  }, [cartItems]);

  useEffect(() => {
    try {
      if (appliedCoupon) {
        localStorage.setItem(COUPON_STORAGE_KEY, JSON.stringify(appliedCoupon));
      } else {
        localStorage.removeItem(COUPON_STORAGE_KEY);
      }
    } catch (e) {
      console.error('Error saving coupon to localStorage', e);
    }
  }, [appliedCoupon]);

  const addToCart = (product, size = 'M', color = 'Olive Green', colorHex = '#556b2f', quantity = 1) => {
    const existingIndex = cartItems.findIndex(
      (item) => item.productId === product.id && item.size === size && item.color === color
    );

    if (existingIndex > -1) {
      const updated = [...cartItems];
      updated[existingIndex].quantity += quantity;
      setCartItems(updated);
    } else {
      const newItem = {
        id: `cart-${product.id}-${size}-${color}-${Date.now()}`,
        productId: product.id,
        name: product.name,
        slug: product.slug,
        category: product.category,
        price: Number(product.price),
        size,
        color,
        colorHex,
        quantity,
        image: product.images ? product.images[0] : (product.image || '')
      };
      setCartItems((prev) => [...prev, newItem]);
    }
  };

  const updateQuantity = (cartItemId, newQty) => {
    if (newQty <= 0) {
      removeFromCart(cartItemId);
      return;
    }
    setCartItems((prev) =>
      prev.map((item) => (item.id === cartItemId ? { ...item, quantity: newQty } : item))
    );
  };

  const removeFromCart = (cartItemId) => {
    setCartItems((prev) => prev.filter((item) => item.id !== cartItemId));
  };

  const clearCart = () => {
    setCartItems([]);
    setAppliedCoupon(null);
    localStorage.removeItem(CART_STORAGE_KEY);
    localStorage.removeItem(COUPON_STORAGE_KEY);
  };

  const resetToDefaultCart = () => {
    setCartItems(DEFAULT_INITIAL_CART);
  };

  const applyCoupon = (code) => {
    const normalized = code.trim().toUpperCase();
    if (normalized === 'SAVE10' || normalized === 'SUMMER10') {
      const coupon = { code: normalized, discountPercent: 10, description: '10% Summer Discount' };
      setAppliedCoupon(coupon);
      return { success: true, message: '10% discount applied successfully!' };
    } else if (normalized === 'FREESHIP') {
      const coupon = { code: normalized, freeShipping: true, description: 'Free Shipping' };
      setAppliedCoupon(coupon);
      return { success: true, message: 'Free shipping coupon applied!' };
    } else {
      return { success: false, message: 'Invalid promo code. Try "SAVE10" or "SUMMER10".' };
    }
  };

  const removeCoupon = () => {
    setAppliedCoupon(null);
  };

  // Calculations
  const totalItemCount = cartItems.reduce((acc, item) => acc + item.quantity, 0);
  const subtotal = cartItems.reduce((acc, item) => acc + item.price * item.quantity, 0);
  
  // Tax rate is 6% matching Figma wireframe ($89.98 * 0.06 = $5.40)
  const tax = Number((subtotal * 0.06).toFixed(2));
  
  // Free shipping if subtotal >= $50 or empty
  const rawShipping = subtotal > 0 && subtotal < 50 && !appliedCoupon?.freeShipping ? 5.00 : 0;
  const shipping = rawShipping;

  const discountAmount = appliedCoupon?.discountPercent
    ? Number(((subtotal * appliedCoupon.discountPercent) / 100).toFixed(2))
    : 0;

  const total = Number((subtotal + tax + shipping - discountAmount).toFixed(2));

  return (
    <CartContext.Provider
      value={{
        cartItems,
        totalItemCount,
        subtotal,
        tax,
        shipping,
        discountAmount,
        appliedCoupon,
        total,
        addToCart,
        updateQuantity,
        removeFromCart,
        clearCart,
        resetToDefaultCart,
        applyCoupon,
        removeCoupon
      }}
    >
      {children}
    </CartContext.Provider>
  );
};

export const useCart = () => useContext(CartContext);
