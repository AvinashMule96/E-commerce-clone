import React, { createContext, useContext, useState, useEffect } from 'react';

const OrderContext = createContext();

const ORDERS_STORAGE_KEY = 'ecommerce_orders_history';
const CURRENT_ORDER_KEY = 'ecommerce_current_order';

export const OrderProvider = ({ children }) => {
  const [orders, setOrders] = useState(() => {
    try {
      const saved = localStorage.getItem(ORDERS_STORAGE_KEY);
      return saved ? JSON.parse(saved) : [];
    } catch (e) {
      return [];
    }
  });

  const [currentOrder, setCurrentOrder] = useState(() => {
    try {
      const saved = localStorage.getItem(CURRENT_ORDER_KEY);
      return saved ? JSON.parse(saved) : null;
    } catch (e) {
      return null;
    }
  });

  useEffect(() => {
    try {
      localStorage.setItem(ORDERS_STORAGE_KEY, JSON.stringify(orders));
    } catch (e) {
      console.error('Error saving orders history', e);
    }
  }, [orders]);

  useEffect(() => {
    try {
      if (currentOrder) {
        localStorage.setItem(CURRENT_ORDER_KEY, JSON.stringify(currentOrder));
      } else {
        localStorage.removeItem(CURRENT_ORDER_KEY);
      }
    } catch (e) {
      console.error('Error saving current order', e);
    }
  }, [currentOrder]);

  const generateOrderId = () => {
    const randomDigits = Math.floor(10000 + Math.random() * 90000);
    return `ORD-2026-${randomDigits}`;
  };

  const createOrder = ({ shippingInfo, paymentMethod, items, subtotal, tax, shipping, discountAmount, total }) => {
    const orderId = generateOrderId();
    const now = new Date();
    
    const formattedDate = now.toLocaleDateString('en-US', {
      year: 'numeric',
      month: 'long',
      day: 'numeric'
    });
    
    const formattedTime = now.toLocaleTimeString('en-US', {
      hour: '2-digit',
      minute: '2-digit'
    });

    const newOrder = {
      id: orderId,
      createdAt: now.toISOString(),
      dateString: `${formattedDate}, ${formattedTime}`,
      status: 'Confirmed',
      customer: {
        fullName: shippingInfo.fullName || 'Customer',
        phone: shippingInfo.phone || '+1 555-0199',
        email: shippingInfo.email || 'customer@example.com',
        address: shippingInfo.address || '123 Fashion Blvd',
        suite: shippingInfo.suite || '',
        city: shippingInfo.city || 'San Francisco',
        state: shippingInfo.state || 'CA',
        zipCode: shippingInfo.zipCode || '94107'
      },
      payment: {
        method: paymentMethod?.type || 'Credit / Debit Card',
        details: paymentMethod?.details || 'Card ending in •••• 4242',
        status: 'Paid'
      },
      items: items.map(item => ({
        id: item.id,
        productId: item.productId,
        name: item.name,
        slug: item.slug,
        category: item.category,
        size: item.size,
        color: item.color,
        colorHex: item.colorHex,
        price: item.price,
        quantity: item.quantity,
        total: Number((item.price * item.quantity).toFixed(2)),
        image: item.image
      })),
      pricing: {
        subtotal: Number(subtotal.toFixed(2)),
        tax: Number(tax.toFixed(2)),
        shipping: Number(shipping.toFixed(2)),
        discount: Number(discountAmount.toFixed(2)),
        total: Number(total.toFixed(2))
      }
    };

    setOrders((prev) => [newOrder, ...prev]);
    setCurrentOrder(newOrder);
    return newOrder;
  };

  const getOrderById = (id) => {
    return orders.find((o) => o.id === id) || (currentOrder?.id === id ? currentOrder : null);
  };

  return (
    <OrderContext.Provider value={{ orders, currentOrder, createOrder, getOrderById, setCurrentOrder }}>
      {children}
    </OrderContext.Provider>
  );
};

export const useOrder = () => useContext(OrderContext);
