import React, { createContext, useContext, useState, useEffect } from 'react';

const AuthContext = createContext();

const STORAGE_KEY = 'ecommerce_user_session';

export const AuthProvider = ({ children }) => {
  const [user, setUser] = useState(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      return saved ? JSON.parse(saved) : {
        id: 'usr-default',
        name: 'Alex Johnson',
        email: 'user@gmail.com',
        phone: '+1 555-0199',
        isLoggedIn: true,
        avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80'
      };
    } catch (e) {
      return null;
    }
  });

  useEffect(() => {
    try {
      if (user) {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(user));
      } else {
        localStorage.removeItem(STORAGE_KEY);
      }
    } catch (e) {
      console.error('Error saving user session', e);
    }
  }, [user]);

  const login = (emailOrPhone, password) => {
    if (!emailOrPhone || !password) {
      return { success: false, error: 'Please fill in both email/phone and password.' };
    }
    if (password.length < 4) {
      return { success: false, error: 'Password must be at least 4 characters.' };
    }

    const newUser = {
      id: 'usr-' + Date.now(),
      name: emailOrPhone.includes('@') ? emailOrPhone.split('@')[0] : 'Customer',
      email: emailOrPhone.includes('@') ? emailOrPhone : 'customer@example.com',
      phone: !emailOrPhone.includes('@') ? emailOrPhone : '+1 555-0199',
      isLoggedIn: true,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80'
    };
    setUser(newUser);
    return { success: true, user: newUser };
  };

  const register = (name, email, password) => {
    if (!name || !email || !password) {
      return { success: false, error: 'All fields are required.' };
    }
    if (!email.includes('@')) {
      return { success: false, error: 'Please enter a valid email address.' };
    }
    if (password.length < 6) {
      return { success: false, error: 'Password must be at least 6 characters long.' };
    }

    const newUser = {
      id: 'usr-' + Date.now(),
      name: name.trim(),
      email: email.trim(),
      phone: '+1 555-0199',
      isLoggedIn: true,
      avatar: 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80'
    };
    setUser(newUser);
    return { success: true, user: newUser };
  };

  const socialLogin = (provider) => {
    const newUser = {
      id: 'usr-' + Date.now(),
      name: provider === 'google' ? 'Google User' : 'Facebook User',
      email: `${provider}.user@gmail.com`,
      phone: '+1 555-0199',
      isLoggedIn: true,
      avatar: provider === 'google'
        ? 'https://images.unsplash.com/photo-1535713875002-d1d0cf377fde?auto=format&fit=crop&w=150&q=80'
        : 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80'
    };
    setUser(newUser);
    return { success: true, user: newUser };
  };

  const logout = () => {
    setUser(null);
    localStorage.removeItem(STORAGE_KEY);
  };

  return (
    <AuthContext.Provider value={{ user, login, register, socialLogin, logout, isAuthenticated: Boolean(user?.isLoggedIn) }}>
      {children}
    </AuthContext.Provider>
  );
};

export const useAuth = () => useContext(AuthContext);
