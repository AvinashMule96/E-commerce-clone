import React, { useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { CartItem } from '../components/CartItem';
import { ChevronLeftIcon, CheckIcon, CloseIcon } from '../components/Icons';

export const CartPage = () => {
  const navigate = useNavigate();
  const {
    cartItems,
    totalItemCount,
    subtotal,
    tax,
    shipping,
    discountAmount,
    appliedCoupon,
    total,
    applyCoupon,
    removeCoupon,
    clearCart,
    resetToDefaultCart
  } = useCart();

  const [couponInput, setCouponInput] = useState('');
  const [couponMessage, setCouponMessage] = useState(null);

  const handleApplyCoupon = (e) => {
    e.preventDefault();
    if (!couponInput.trim()) return;
    const res = applyCoupon(couponInput);
    setCouponMessage(res);
    if (res.success) {
      setCouponInput('');
    }
  };

  if (cartItems.length === 0) {
    return (
      <div className="empty-cart-page-container">
        <div className="empty-cart-card">
          <div className="empty-cart-icon">🛍️</div>
          <h2>Your Cart is Empty</h2>
          <p>Looks like you haven't added any items to your shopping cart yet.</p>
          <div className="empty-cart-actions">
            <Link to="/category" className="primary-btn">
              Start Shopping
            </Link>
            <button
              type="button"
              className="secondary-btn"
              onClick={resetToDefaultCart}
            >
              Load Figma Demo Cart Items
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="cart-page-container">
      {/* Header */}
      <div className="cart-header-title-row">
        <h1 className="cart-main-heading">
          Your Cart <span className="cart-count-sub">({totalItemCount} {totalItemCount === 1 ? 'Item' : 'Items'})</span>
        </h1>
        <button
          type="button"
          className="clear-cart-link"
          onClick={clearCart}
          title="Remove all items"
        >
          Clear Cart
        </button>
      </div>

      <div className="cart-layout-grid">
        {/* Left: Cart Items List */}
        <div className="cart-items-column">
          <div className="cart-items-card">
            <div className="cart-table-header">
              <span className="th-col-prod">Product</span>
              <span className="th-col-qty">Quantity</span>
              <span className="th-col-tot">Total</span>
            </div>

            <div className="cart-items-list-body">
              {cartItems.map((item) => (
                <CartItem key={item.id} item={item} />
              ))}
            </div>
          </div>

          {/* Promo Code Card */}
          <div className="coupon-promo-card">
            <h4 className="coupon-card-title">Have a Promo or Referral Code?</h4>
            {appliedCoupon ? (
              <div className="applied-coupon-badge">
                <div className="coupon-info-text">
                  <CheckIcon size={18} />
                  <span>
                    Coupon <strong>{appliedCoupon.code}</strong> applied ({appliedCoupon.description})
                  </span>
                </div>
                <button
                  type="button"
                  className="remove-coupon-btn"
                  onClick={removeCoupon}
                  aria-label="Remove coupon"
                >
                  <CloseIcon size={16} />
                </button>
              </div>
            ) : (
              <form className="coupon-input-form" onSubmit={handleApplyCoupon}>
                <input
                  type="text"
                  placeholder="Enter code (e.g. SAVE10)"
                  value={couponInput}
                  onChange={(e) => setCouponInput(e.target.value)}
                  className="coupon-input-field"
                />
                <button type="submit" className="coupon-apply-btn">
                  Apply
                </button>
              </form>
            )}

            {couponMessage && (
              <div className={`coupon-feedback-msg ${couponMessage.success ? 'success' : 'error'}`}>
                {couponMessage.message}
              </div>
            )}
          </div>
        </div>

        {/* Right: PRICE DETAILS Card matching Figma wireframe */}
        <div className="cart-summary-column">
          <div className="price-details-card">
            <h3 className="price-details-heading">PRICE DETAILS</h3>

            <div className="price-breakdown-list">
              <div className="price-line-row">
                <span className="line-label">Subtotal ({totalItemCount} Items)</span>
                <span className="line-value">${subtotal.toFixed(2)}</span>
              </div>

              {discountAmount > 0 && (
                <div className="price-line-row discount-row">
                  <span className="line-label">Coupon Discount</span>
                  <span className="line-value">-${discountAmount.toFixed(2)}</span>
                </div>
              )}

              <div className="price-line-row">
                <span className="line-label">Shipping</span>
                <span className="line-value shipping-free">
                  {shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}
                </span>
              </div>

              <div className="price-line-row">
                <span className="line-label">Tax (6%)</span>
                <span className="line-value">${tax.toFixed(2)}</span>
              </div>

              <div className="price-details-divider"></div>

              <div className="price-line-row total-row">
                <span className="line-label total-label">Total</span>
                <span className="line-value total-val">${total.toFixed(2)}</span>
              </div>
            </div>

            {/* Checkout Action Button */}
            <button
              type="button"
              className="proceed-checkout-btn"
              onClick={() => navigate('/checkout')}
            >
              PROCEED TO CHECKOUT
            </button>

            {/* Continue Shopping Link */}
            <div className="continue-shopping-wrapper">
              <Link to="/category" className="continue-shopping-link">
                <ChevronLeftIcon size={16} />
                <span>CONTINUE SHOPPING</span>
              </Link>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};
