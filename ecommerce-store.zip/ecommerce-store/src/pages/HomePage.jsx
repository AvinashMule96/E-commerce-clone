import React from 'react';
import { Link } from 'react-router-dom';
import { HeroCarousel } from '../components/HeroCarousel';
import { TrustBadges } from '../components/TrustBadges';
import { CategoryCards } from '../components/CategoryCards';
import { ProductCard } from '../components/ProductCard';
import { Testimonials } from '../components/Testimonials';
import { BookingWidget } from '../components/BookingWidget';
import { products } from '../data/products';
import { ChevronRightIcon } from '../components/Icons';

export const HomePage = () => {
  // Best selling products matching Figma wireframe
  const bestSellers = products.filter((p) => p.isBestSeller).slice(0, 6);
  const featuredProducts = products.filter((p) => p.isFeatured).slice(0, 4);

  return (
    <div className="homepage-container">
      {/* 1. Hero Carousel Banner */}
      <HeroCarousel />

      {/* 2. Trust Badges / Value Proposition */}
      <div className="section-content-wrapper">
        <TrustBadges />
      </div>

      {/* 3. Top Categories Section */}
      <div className="section-content-wrapper">
        <CategoryCards />
      </div>

      {/* 4. Best Selling Products Section (Matches Figma Wireframe) */}
      <section className="section-content-wrapper products-showcase-section">
        <div className="section-header-row">
          <h2 className="section-title-heading">Best Selling Products</h2>
          <Link to="/category" className="view-all-link">
            <span>View All</span>
            <ChevronRightIcon size={16} />
          </Link>
        </div>

        <div className="products-grid-layout">
          {bestSellers.map((product) => (
            <ProductCard key={product.id} product={product} />
          ))}
        </div>
      </section>

      {/* 5. Featured Deals Banner */}
      <section className="section-content-wrapper deals-highlight-banner">
        <div className="deals-banner-card">
          <div className="deals-banner-content">
            <span className="deals-pill-tag">SPECIAL PROMOTION</span>
            <h3 className="deals-banner-title">Elevate Your Signature Everyday Look</h3>
            <p className="deals-banner-desc">
              Get an extra 10% off your entire order today. Use code <code className="promo-highlight-code">SAVE10</code> at checkout.
            </p>
            <Link to="/category?cat=deals" className="primary-btn-white">
              Explore Deals
            </Link>
          </div>
          <div className="deals-banner-img-box">
            <img
              src="https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=800&q=80"
              alt="Seasonal Lookbook"
              className="deals-promo-img"
            />
          </div>
        </div>
      </section>

      {/* 6. Testimonials Section (Matches Figma Wireframe) */}
      <div className="section-content-wrapper">
        <Testimonials />
      </div>

      {/* 7. Book / Calendar Consultation Widget (Matches Figma Wireframe) */}
      <div className="section-content-wrapper">
        <BookingWidget />
      </div>
    </div>
  );
};
