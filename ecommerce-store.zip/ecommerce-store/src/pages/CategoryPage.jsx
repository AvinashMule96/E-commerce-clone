import React, { useState, useMemo, useEffect } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import { products } from '../data/products';
import { categories } from '../data/categories';
import { ProductCard } from '../components/ProductCard';
import { FilterSidebar } from '../components/FilterSidebar';
import { SearchIcon, ChevronRightIcon, ChevronLeftIcon, CloseIcon } from '../components/Icons';

export const CategoryPage = () => {
  const [searchParams, setSearchParams] = useSearchParams();

  // Read URL parameters
  const initialCategory = searchParams.get('cat') || 'all';
  const initialSearch = searchParams.get('search') || '';

  const [selectedCategory, setSelectedCategory] = useState(initialCategory);
  const [searchQuery, setSearchQuery] = useState(initialSearch);
  const [priceRange, setPriceRange] = useState(200);
  const [selectedBrands, setSelectedBrands] = useState([]);
  const [selectedSizes, setSelectedSizes] = useState([]);
  const [selectedColors, setSelectedColors] = useState([]);
  const [sortBy, setSortBy] = useState('popularity');
  const [currentPage, setCurrentPage] = useState(1);
  const [isMobileFilterOpen, setIsMobileFilterOpen] = useState(false);

  // Sync state with URL changes
  useEffect(() => {
    const cat = searchParams.get('cat') || 'all';
    const search = searchParams.get('search') || '';
    setSelectedCategory(cat);
    setSearchQuery(search);
    setCurrentPage(1);
  }, [searchParams]);

  const handleCategorySelect = (slug) => {
    setSelectedCategory(slug);
    setCurrentPage(1);
    if (slug === 'all') {
      searchParams.delete('cat');
    } else {
      searchParams.set('cat', slug);
    }
    setSearchParams(searchParams);
  };

  const handleToggleBrand = (brand) => {
    setSelectedBrands((prev) =>
      prev.includes(brand) ? prev.filter((b) => b !== brand) : [...prev, brand]
    );
    setCurrentPage(1);
  };

  const handleToggleSize = (size) => {
    setSelectedSizes((prev) =>
      prev.includes(size) ? prev.filter((s) => s !== size) : [...prev, size]
    );
    setCurrentPage(1);
  };

  const handleToggleColor = (colorName) => {
    setSelectedColors((prev) =>
      prev.includes(colorName) ? prev.filter((c) => c !== colorName) : [...prev, colorName]
    );
    setCurrentPage(1);
  };

  const handleResetFilters = () => {
    setSelectedCategory('all');
    setPriceRange(200);
    setSelectedBrands([]);
    setSelectedSizes([]);
    setSelectedColors([]);
    setSearchQuery('');
    setSortBy('popularity');
    setCurrentPage(1);
    setSearchParams({});
  };

  // Filter & Sort Logic
  const filteredProducts = useMemo(() => {
    return products.filter((item) => {
      // Category check
      if (selectedCategory && selectedCategory !== 'all') {
        if (selectedCategory === 'deals') {
          if (!item.originalPrice || item.originalPrice <= item.price) return false;
        } else if (item.category !== selectedCategory) {
          return false;
        }
      }

      // Search keyword check
      if (searchQuery.trim()) {
        const query = searchQuery.toLowerCase();
        const matchName = item.name.toLowerCase().includes(query);
        const matchCat = item.category.toLowerCase().includes(query);
        const matchBrand = item.brand ? item.brand.toLowerCase().includes(query) : false;
        const matchDesc = item.shortDescription.toLowerCase().includes(query);
        if (!matchName && !matchCat && !matchBrand && !matchDesc) {
          return false;
        }
      }

      // Price slider
      if (item.price > priceRange) {
        return false;
      }

      // Brand filter
      if (selectedBrands.length > 0 && !selectedBrands.includes(item.brand)) {
        return false;
      }

      // Size filter
      if (selectedSizes.length > 0) {
        const hasSize = item.sizes?.some((s) => selectedSizes.includes(s));
        if (!hasSize) return false;
      }

      // Color filter
      if (selectedColors.length > 0) {
        const hasColor = item.colors?.some((c) => selectedColors.includes(c.name));
        if (!hasColor) return false;
      }

      return true;
    }).sort((a, b) => {
      if (sortBy === 'price-asc') return a.price - b.price;
      if (sortBy === 'price-desc') return b.price - a.price;
      if (sortBy === 'rating') return (b.rating || 0) - (a.rating || 0);
      if (sortBy === 'newest') return b.id.localeCompare(a.id);
      // Popularity default
      return (b.reviewsCount || 0) - (a.reviewsCount || 0);
    });
  }, [selectedCategory, searchQuery, priceRange, selectedBrands, selectedSizes, selectedColors, sortBy]);

  // Pagination calculations (9 items per page)
  const itemsPerPage = 6;
  const totalPages = Math.max(1, Math.ceil(filteredProducts.length / itemsPerPage));
  const currentItems = filteredProducts.slice(
    (currentPage - 1) * itemsPerPage,
    currentPage * itemsPerPage
  );

  const activeCategoryObj = categories.find((c) => c.slug === selectedCategory);
  const activeCategoryName = activeCategoryObj ? activeCategoryObj.name : 'All Products';

  return (
    <div className="category-page-container">
      {/* Breadcrumb Bar */}
      <div className="breadcrumbs-bar">
        <div className="breadcrumbs-content">
          <Link to="/" className="breadcrumb-link">Home</Link>
          <ChevronRightIcon size={14} className="breadcrumb-separator" />
          <span className="breadcrumb-current">{activeCategoryName}</span>
          {searchQuery && (
            <>
              <ChevronRightIcon size={14} className="breadcrumb-separator" />
              <span className="breadcrumb-current">"{searchQuery}"</span>
            </>
          )}
        </div>
      </div>

      <div className="category-layout-wrapper">
        {/* Mobile Filter Toggle Button */}
        <div className="mobile-filter-trigger-row">
          <button
            type="button"
            className="mobile-filter-btn"
            onClick={() => setIsMobileFilterOpen(true)}
          >
            Filters & Categories
          </button>
          <div className="mobile-sort-select">
            <select
              value={sortBy}
              onChange={(e) => setSortBy(e.target.value)}
              className="sort-dropdown"
            >
              <option value="popularity">Sort by: Popularity</option>
              <option value="price-asc">Price: Low to High</option>
              <option value="price-desc">Price: High to Low</option>
              <option value="rating">Highest Rated</option>
              <option value="newest">Newest Arrivals</option>
            </select>
          </div>
        </div>

        {/* Left Filter Sidebar - Desktop & Drawer on Mobile */}
        <div className={`sidebar-column ${isMobileFilterOpen ? 'mobile-visible' : ''}`}>
          <div className="mobile-sidebar-header">
            <h3>Filters</h3>
            <button
              className="close-sidebar-btn"
              onClick={() => setIsMobileFilterOpen(false)}
            >
              <CloseIcon size={20} />
            </button>
          </div>
          <FilterSidebar
            selectedCategory={selectedCategory}
            onSelectCategory={(slug) => {
              handleCategorySelect(slug);
              setIsMobileFilterOpen(false);
            }}
            priceRange={priceRange}
            onPriceChange={setPriceRange}
            selectedBrands={selectedBrands}
            onToggleBrand={handleToggleBrand}
            selectedSizes={selectedSizes}
            onToggleSize={handleToggleSize}
            selectedColors={selectedColors}
            onToggleColor={handleToggleColor}
            onResetFilters={handleResetFilters}
          />
        </div>

        {/* Right Product Grid Area */}
        <main className="catalog-main-column">
          {/* Header Controls */}
          <div className="catalog-header-bar">
            <div className="results-count-meta">
              Showing {filteredProducts.length > 0 ? (currentPage - 1) * itemsPerPage + 1 : 0} -{' '}
              {Math.min(currentPage * itemsPerPage, filteredProducts.length)} of{' '}
              <strong>{filteredProducts.length}</strong> products
            </div>

            <div className="catalog-sort-wrapper desktop-only">
              <label htmlFor="sort-select" className="sort-label">Sort by:</label>
              <select
                id="sort-select"
                value={sortBy}
                onChange={(e) => setSortBy(e.target.value)}
                className="sort-dropdown"
              >
                <option value="popularity">Popularity</option>
                <option value="price-asc">Price: Low to High</option>
                <option value="price-desc">Price: High to Low</option>
                <option value="rating">Customer Rating</option>
                <option value="newest">Newest</option>
              </select>
            </div>
          </div>

          {/* Active Filter Tags */}
          {(selectedCategory !== 'all' || selectedBrands.length > 0 || selectedSizes.length > 0 || selectedColors.length > 0 || searchQuery) && (
            <div className="active-filter-tags-row">
              <span className="tags-label">Active Filters:</span>
              {selectedCategory !== 'all' && (
                <span className="filter-pill-tag">
                  Category: {activeCategoryName}
                  <button onClick={() => handleCategorySelect('all')}>×</button>
                </span>
              )}
              {searchQuery && (
                <span className="filter-pill-tag">
                  Keyword: "{searchQuery}"
                  <button onClick={() => setSearchQuery('')}>×</button>
                </span>
              )}
              {selectedBrands.map((b) => (
                <span key={b} className="filter-pill-tag">
                  {b}
                  <button onClick={() => handleToggleBrand(b)}>×</button>
                </span>
              ))}
              {selectedSizes.map((s) => (
                <span key={s} className="filter-pill-tag">
                  Size {s}
                  <button onClick={() => handleToggleSize(s)}>×</button>
                </span>
              ))}
              {selectedColors.map((c) => (
                <span key={c} className="filter-pill-tag">
                  Color {c}
                  <button onClick={() => handleToggleColor(c)}>×</button>
                </span>
              ))}
              <button
                className="clear-all-tags-btn"
                onClick={handleResetFilters}
              >
                Clear All
              </button>
            </div>
          )}

          {/* Product Grid */}
          {currentItems.length > 0 ? (
            <div className="catalog-products-grid">
              {currentItems.map((product) => (
                <ProductCard key={product.id} product={product} />
              ))}
            </div>
          ) : (
            <div className="empty-catalog-box">
              <div className="empty-icon">🔍</div>
              <h3>No products found</h3>
              <p>Try clearing your filters or searching for another keyword.</p>
              <button
                className="primary-btn mt-4"
                onClick={handleResetFilters}
              >
                Reset All Filters
              </button>
            </div>
          )}

          {/* Pagination Controls matching Figma */}
          {totalPages > 1 && (
            <div className="pagination-bar-wrapper">
              <button
                className="pagination-arrow-btn"
                disabled={currentPage === 1}
                onClick={() => setCurrentPage((p) => Math.max(1, p - 1))}
                aria-label="Previous Page"
              >
                <ChevronLeftIcon size={16} />
              </button>

              <div className="pagination-numbers">
                {Array.from({ length: totalPages }, (_, i) => i + 1).map((pageNum) => (
                  <button
                    key={pageNum}
                    className={`page-num-btn ${currentPage === pageNum ? 'active' : ''}`}
                    onClick={() => setCurrentPage(pageNum)}
                  >
                    {pageNum}
                  </button>
                ))}
              </div>

              <button
                className="pagination-arrow-btn"
                disabled={currentPage === totalPages}
                onClick={() => setCurrentPage((p) => Math.min(totalPages, p + 1))}
                aria-label="Next Page"
              >
                <ChevronRightIcon size={16} />
              </button>
            </div>
          )}
        </main>
      </div>
    </div>
  );
};
