import React, { useState } from 'react';
import { useNavigate, useLocation, Link } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { UserIcon, GoogleIcon, FacebookIcon, CheckIcon, CloseIcon } from '../components/Icons';

export const LoginPage = () => {
  const navigate = useNavigate();
  const location = useLocation();
  const { login, register, socialLogin, isAuthenticated, user, logout } = useAuth();

  const [isRegisterMode, setIsRegisterMode] = useState(false);
  const [emailOrPhone, setEmailOrPhone] = useState('user@gmail.com');
  const [password, setPassword] = useState('password123');
  const [fullName, setFullName] = useState('');
  const [errorMessage, setErrorMessage] = useState('');
  const [showForgotModal, setShowForgotModal] = useState(false);
  const [forgotEmail, setForgotEmail] = useState('');
  const [forgotSubmitted, setForgotSubmitted] = useState(false);

  const handleSubmit = (e) => {
    e.preventDefault();
    setErrorMessage('');

    if (isRegisterMode) {
      const res = register(fullName, emailOrPhone, password);
      if (res.success) {
        navigate('/');
      } else {
        setErrorMessage(res.error);
      }
    } else {
      const res = login(emailOrPhone, password);
      if (res.success) {
        navigate('/');
      } else {
        setErrorMessage(res.error);
      }
    }
  };

  const handleSocialClick = (provider) => {
    socialLogin(provider);
    navigate('/');
  };

  const handleForgotSubmit = (e) => {
    e.preventDefault();
    if (forgotEmail.trim()) {
      setForgotSubmitted(true);
      setTimeout(() => {
        setForgotSubmitted(false);
        setShowForgotModal(false);
        setForgotEmail('');
      }, 2500);
    }
  };

  return (
    <div className="login-page-container">
      <div className="login-card-wrapper">
        <div className="login-card-box">
          {/* Avatar circle icon at top matching Figma wireframe */}
          <div className="login-avatar-circle">
            <UserIcon size={32} />
          </div>

          <h2 className="login-heading-title">
            {isRegisterMode ? 'Create an Account' : 'Welcome Back'}
          </h2>
          <p className="login-sub-text">
            {isRegisterMode
              ? 'Join VELOUR for exclusive seasonal perks and rewards.'
              : 'Sign in to access your orders, saved cart, and wishlist.'}
          </p>

          {/* If already logged in, show status */}
          {isAuthenticated && user && (
            <div className="already-logged-banner">
              <p>
                You are currently logged in as <strong>{user.email}</strong>.
              </p>
              <div className="logged-actions-row">
                <Link to="/" className="primary-btn">Go to Shop</Link>
                <button type="button" className="secondary-outline-btn" onClick={logout}>
                  Log Out
                </button>
              </div>
            </div>
          )}

          {/* Form */}
          {!isAuthenticated && (
            <form onSubmit={handleSubmit} className="auth-form-layout">
              {errorMessage && (
                <div className="auth-error-banner">
                  <span>{errorMessage}</span>
                </div>
              )}

              {isRegisterMode && (
                <div className="form-group-field">
                  <label>Full Name</label>
                  <input
                    type="text"
                    placeholder="Enter your full name"
                    value={fullName}
                    onChange={(e) => setFullName(e.target.value)}
                    required
                  />
                </div>
              )}

              <div className="form-group-field">
                <label>Email / Phone</label>
                <input
                  type="text"
                  placeholder="Email / Phone"
                  value={emailOrPhone}
                  onChange={(e) => setEmailOrPhone(e.target.value)}
                  required
                />
              </div>

              <div className="form-group-field">
                <div className="password-label-row">
                  <label>Password</label>
                  {!isRegisterMode && (
                    <button
                      type="button"
                      className="forgot-pwd-link"
                      onClick={() => setShowForgotModal(true)}
                    >
                      Forgot Password?
                    </button>
                  )}
                </div>
                <input
                  type="password"
                  placeholder="Password"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  required
                />
              </div>

              <button type="submit" className="login-primary-dark-btn">
                {isRegisterMode ? 'CREATE ACCOUNT' : 'LOGIN'}
              </button>

              {/* Separator */}
              <div className="auth-separator-divider">
                <span>or</span>
              </div>

              {/* Social Login Buttons matching Figma wireframe */}
              <div className="social-login-group">
                <button
                  type="button"
                  className="social-auth-btn google-btn"
                  onClick={() => handleSocialClick('google')}
                >
                  <GoogleIcon size={18} />
                  <span>Login with Google</span>
                </button>

                <button
                  type="button"
                  className="social-auth-btn facebook-btn"
                  onClick={() => handleSocialClick('facebook')}
                >
                  <FacebookIcon size={18} />
                  <span>Login with Facebook</span>
                </button>
              </div>

              {/* Toggle Register / Login switch */}
              <div className="auth-switch-prompt">
                {isRegisterMode ? (
                  <p>
                    Already have an account?{' '}
                    <button
                      type="button"
                      className="switch-mode-link"
                      onClick={() => setIsRegisterMode(false)}
                    >
                      Login
                    </button>
                  </p>
                ) : (
                  <p>
                    Don't have an account?{' '}
                    <button
                      type="button"
                      className="switch-mode-link"
                      onClick={() => setIsRegisterMode(true)}
                    >
                      Sign Up
                    </button>
                  </p>
                )}
              </div>
            </form>
          )}
        </div>
      </div>

      {/* Forgot Password Modal */}
      {showForgotModal && (
        <div className="modal-overlay" onClick={() => setShowForgotModal(false)}>
          <div className="modal-content-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-card-header-row">
              <h3>Reset Your Password</h3>
              <button
                className="close-modal-btn"
                onClick={() => setShowForgotModal(false)}
              >
                <CloseIcon size={18} />
              </button>
            </div>

            {forgotSubmitted ? (
              <div className="modal-success-state">
                <div className="success-icon-circle">
                  <CheckIcon size={24} />
                </div>
                <h4>Password Reset Link Sent</h4>
                <p>We've sent recovery instructions to <strong>{forgotEmail}</strong>.</p>
              </div>
            ) : (
              <form onSubmit={handleForgotSubmit} className="forgot-form">
                <p className="forgot-instructions">
                  Enter your email address and we'll send you a secure link to reset your account password.
                </p>
                <div className="form-group-field">
                  <label>Email Address</label>
                  <input
                    type="email"
                    placeholder="Enter your registered email"
                    value={forgotEmail}
                    onChange={(e) => setForgotEmail(e.target.value)}
                    required
                  />
                </div>
                <button type="submit" className="primary-btn full-width mt-4">
                  Send Reset Link
                </button>
              </form>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
