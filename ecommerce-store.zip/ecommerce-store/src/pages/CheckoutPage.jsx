import React, { useState } from 'react';
import { useNavigate, Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useAuth } from '../context/AuthContext';
import { useOrder } from '../context/OrderContext';
import { CheckIcon, CreditCardIcon, ChevronLeftIcon } from '../components/Icons';

export const CheckoutPage = () => {
  const navigate = useNavigate();
  const { user } = useAuth();
  const { cartItems, subtotal, tax, shipping, discountAmount, total, clearCart } = useCart();
  const { createOrder } = useOrder();

  const [currentStep, setCurrentStep] = useState(1); // 1: Shipping, 2: Payment, 3: Review

  // Shipping Form State matching Figma
  const [shippingInfo, setShippingInfo] = useState({
    fullName: user?.name || 'Alex Johnson',
    phone: user?.phone || '+1 (555) 234-5678',
    email: user?.email || 'user@gmail.com',
    address: '742 Evergreen Terrace',
    suite: 'Apt 4B',
    city: 'Springfield',
    state: 'CA',
    zipCode: '97477'
  });

  const [shippingErrors, setShippingErrors] = useState({});

  // Payment State matching Figma
  const [paymentMethod, setPaymentMethod] = useState('card'); // 'card' | 'upi' | 'netbanking' | 'wallets'
  const [cardDetails, setCardDetails] = useState({
    cardNumber: '•••• •••• •••• 4242',
    cardName: user?.name || 'Alex Johnson',
    expiry: '08/28',
    cvv: '888'
  });
  const [upiId, setUpiId] = useState('alex@oksbi');
  const [selectedBank, setSelectedBank] = useState('Chase Bank / HDFC');
  const [isProcessingOrder, setIsProcessingOrder] = useState(false);

  // Validate Shipping Step
  const validateShipping = () => {
    const errors = {};
    if (!shippingInfo.fullName.trim()) errors.fullName = 'Full name is required';
    if (!shippingInfo.phone.trim()) errors.phone = 'Phone number is required';
    if (!shippingInfo.address.trim()) errors.address = 'Street address is required';
    if (!shippingInfo.city.trim()) errors.city = 'City is required';
    if (!shippingInfo.state.trim()) errors.state = 'State is required';
    if (!shippingInfo.zipCode.trim()) errors.zipCode = 'ZIP code is required';

    setShippingErrors(errors);
    return Object.keys(errors).length === 0;
  };

  const handleContinueToPayment = (e) => {
    e.preventDefault();
    if (validateShipping()) {
      setCurrentStep(2);
      window.scrollTo(0, 0);
    }
  };

  const handleContinueToReview = (e) => {
    e.preventDefault();
    setCurrentStep(3);
    window.scrollTo(0, 0);
  };

  const handlePlaceOrder = () => {
    if (cartItems.length === 0) {
      alert('Your cart is empty.');
      return;
    }

    setIsProcessingOrder(true);

    let paymentSummary = {
      type: 'Credit / Debit Card',
      details: `Card ending in •••• ${cardDetails.cardNumber.slice(-4) || '4242'}`
    };

    if (paymentMethod === 'upi') {
      paymentSummary = {
        type: 'UPI Payment',
        details: `UPI ID: ${upiId || 'user@upi'}`
      };
    } else if (paymentMethod === 'netbanking') {
      paymentSummary = {
        type: 'Net Banking',
        details: `Bank: ${selectedBank}`
      };
    } else if (paymentMethod === 'wallets') {
      paymentSummary = {
        type: 'Digital Wallet / COD',
        details: 'Verified on delivery'
      };
    }

    setTimeout(() => {
      const order = createOrder({
        shippingInfo,
        paymentMethod: paymentSummary,
        items: cartItems,
        subtotal,
        tax,
        shipping,
        discountAmount,
        total
      });

      clearCart();
      setIsProcessingOrder(false);
      navigate(`/order-success?orderId=${order.id}`);
    }, 1200);
  };

  if (cartItems.length === 0 && !isProcessingOrder) {
    return (
      <div className="empty-cart-page-container">
        <div className="empty-cart-card">
          <h2>No Items to Checkout</h2>
          <p>Please add products to your cart before proceeding to checkout.</p>
          <Link to="/category" className="primary-btn mt-4">
            Browse Products
          </Link>
        </div>
      </div>
    );
  }

  return (
    <div className="checkout-page-container">
      {/* 3-Step Stepper Header matching Figma: [1 Shipping] [2 Payment] [3 Review] */}
      <div className="checkout-stepper-wrapper">
        <div className="stepper-track">
          <button
            type="button"
            className={`step-bubble-btn ${currentStep >= 1 ? 'active' : ''} ${currentStep > 1 ? 'completed' : ''}`}
            onClick={() => setCurrentStep(1)}
          >
            <span className="step-num">{currentStep > 1 ? '✓' : '1'}</span>
            <span className="step-text">Shipping</span>
          </button>

          <div className={`stepper-line ${currentStep >= 2 ? 'active' : ''}`}></div>

          <button
            type="button"
            className={`step-bubble-btn ${currentStep >= 2 ? 'active' : ''} ${currentStep > 2 ? 'completed' : ''}`}
            onClick={() => validateShipping() && setCurrentStep(2)}
          >
            <span className="step-num">{currentStep > 2 ? '✓' : '2'}</span>
            <span className="step-text">Payment</span>
          </button>

          <div className={`stepper-line ${currentStep >= 3 ? 'active' : ''}`}></div>

          <button
            type="button"
            className={`step-bubble-btn ${currentStep === 3 ? 'active' : ''}`}
            onClick={() => validateShipping() && setCurrentStep(3)}
          >
            <span className="step-num">3</span>
            <span className="step-text">Review</span>
          </button>
        </div>
      </div>

      <div className="checkout-content-grid">
        {/* Left Column: Active Step Form */}
        <div className="checkout-main-form-column">
          {/* STEP 1: SHIPPING INFORMATION matching Figma wireframe */}
          {currentStep === 1 && (
            <div className="checkout-card-box">
              <h2 className="checkout-card-title">Shipping Information</h2>

              <form onSubmit={handleContinueToPayment} className="shipping-form-layout">
                <div className="form-group-field">
                  <label>Full Name *</label>
                  <input
                    type="text"
                    placeholder="Enter full name"
                    value={shippingInfo.fullName}
                    onChange={(e) => setShippingInfo({ ...shippingInfo, fullName: e.target.value })}
                    className={shippingErrors.fullName ? 'has-error' : ''}
                  />
                  {shippingErrors.fullName && <span className="field-error">{shippingErrors.fullName}</span>}
                </div>

                <div className="form-row-2col">
                  <div className="form-group-field">
                    <label>Phone Number *</label>
                    <input
                      type="tel"
                      placeholder="Enter phone number"
                      value={shippingInfo.phone}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, phone: e.target.value })}
                      className={shippingErrors.phone ? 'has-error' : ''}
                    />
                    {shippingErrors.phone && <span className="field-error">{shippingErrors.phone}</span>}
                  </div>

                  <div className="form-group-field">
                    <label>Email Address *</label>
                    <input
                      type="email"
                      placeholder="Enter email address"
                      value={shippingInfo.email}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, email: e.target.value })}
                    />
                  </div>
                </div>

                <div className="form-group-field">
                  <label>Address *</label>
                  <input
                    type="text"
                    placeholder="House no., Street name"
                    value={shippingInfo.address}
                    onChange={(e) => setShippingInfo({ ...shippingInfo, address: e.target.value })}
                    className={shippingErrors.address ? 'has-error' : ''}
                  />
                  {shippingErrors.address && <span className="field-error">{shippingErrors.address}</span>}
                </div>

                <div className="form-group-field">
                  <label>Apartment / Suite</label>
                  <input
                    type="text"
                    placeholder="Apartment, suite, unit (optional)"
                    value={shippingInfo.suite}
                    onChange={(e) => setShippingInfo({ ...shippingInfo, suite: e.target.value })}
                  />
                </div>

                <div className="form-row-3col">
                  <div className="form-group-field">
                    <label>City *</label>
                    <input
                      type="text"
                      placeholder="Enter city"
                      value={shippingInfo.city}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, city: e.target.value })}
                      className={shippingErrors.city ? 'has-error' : ''}
                    />
                    {shippingErrors.city && <span className="field-error">{shippingErrors.city}</span>}
                  </div>

                  <div className="form-group-field">
                    <label>State *</label>
                    <input
                      type="text"
                      placeholder="State"
                      value={shippingInfo.state}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, state: e.target.value })}
                      className={shippingErrors.state ? 'has-error' : ''}
                    />
                    {shippingErrors.state && <span className="field-error">{shippingErrors.state}</span>}
                  </div>

                  <div className="form-group-field">
                    <label>ZIP / Postal Code *</label>
                    <input
                      type="text"
                      placeholder="Enter zip code"
                      value={shippingInfo.zipCode}
                      onChange={(e) => setShippingInfo({ ...shippingInfo, zipCode: e.target.value })}
                      className={shippingErrors.zipCode ? 'has-error' : ''}
                    />
                    {shippingErrors.zipCode && <span className="field-error">{shippingErrors.zipCode}</span>}
                  </div>
                </div>

                <button type="submit" className="checkout-action-dark-btn">
                  CONTINUE TO PAYMENT
                </button>
              </form>
            </div>
          )}

          {/* STEP 2: PAYMENT METHOD matching Figma wireframe */}
          {currentStep === 2 && (
            <div className="checkout-card-box">
              <h2 className="checkout-card-title">Select Payment Method</h2>

              <div className="payment-options-list">
                {/* 1. Credit / Debit Card Option */}
                <div className={`payment-method-option-card ${paymentMethod === 'card' ? 'selected' : ''}`}>
                  <label className="payment-radio-label">
                    <input
                      type="radio"
                      name="paymentOption"
                      value="card"
                      checked={paymentMethod === 'card'}
                      onChange={() => setPaymentMethod('card')}
                    />
                    <span className="custom-radio-dot"></span>
                    <span className="payment-method-name">Credit / Debit Card</span>
                  </label>

                  <div className="card-brand-pills-row">
                    <span className="card-pill">VISA</span>
                    <span className="card-pill">Mastercard</span>
                    <span className="card-pill">AMEX</span>
                    <span className="card-pill">RuPay</span>
                  </div>

                  {paymentMethod === 'card' && (
                    <div className="card-details-nested-form">
                      <div className="form-group-field">
                        <label>Card Number</label>
                        <input
                          type="text"
                          placeholder="4242 •••• •••• 4242"
                          value={cardDetails.cardNumber}
                          onChange={(e) => setCardDetails({ ...cardDetails, cardNumber: e.target.value })}
                        />
                      </div>

                      <div className="form-row-2col">
                        <div className="form-group-field">
                          <label>Expiry (MM/YY)</label>
                          <input
                            type="text"
                            placeholder="MM/YY"
                            value={cardDetails.expiry}
                            onChange={(e) => setCardDetails({ ...cardDetails, expiry: e.target.value })}
                          />
                        </div>

                        <div className="form-group-field">
                          <label>CVV / CVC</label>
                          <input
                            type="password"
                            maxLength={4}
                            placeholder="CVV"
                            value={cardDetails.cvv}
                            onChange={(e) => setCardDetails({ ...cardDetails, cvv: e.target.value })}
                          />
                        </div>
                      </div>

                      <div className="form-group-field">
                        <label>Name on Card</label>
                        <input
                          type="text"
                          placeholder="Cardholder full name"
                          value={cardDetails.cardName}
                          onChange={(e) => setCardDetails({ ...cardDetails, cardName: e.target.value })}
                        />
                      </div>
                    </div>
                  )}
                </div>

                {/* 2. UPI Option */}
                <div className={`payment-method-option-card ${paymentMethod === 'upi' ? 'selected' : ''}`}>
                  <label className="payment-radio-label">
                    <input
                      type="radio"
                      name="paymentOption"
                      value="upi"
                      checked={paymentMethod === 'upi'}
                      onChange={() => setPaymentMethod('upi')}
                    />
                    <span className="custom-radio-dot"></span>
                    <span className="payment-method-name">UPI (Google Pay, PhonePe, Paytm)</span>
                  </label>

                  {paymentMethod === 'upi' && (
                    <div className="nested-payment-input-box">
                      <label>Enter Virtual Payment Address (VPA) / UPI ID</label>
                      <input
                        type="text"
                        placeholder="username@bank"
                        value={upiId}
                        onChange={(e) => setUpiId(e.target.value)}
                      />
                      <span className="helper-text">You will receive a collect request in your UPI app.</span>
                    </div>
                  )}
                </div>

                {/* 3. Net Banking Option */}
                <div className={`payment-method-option-card ${paymentMethod === 'netbanking' ? 'selected' : ''}`}>
                  <label className="payment-radio-label">
                    <input
                      type="radio"
                      name="paymentOption"
                      value="netbanking"
                      checked={paymentMethod === 'netbanking'}
                      onChange={() => setPaymentMethod('netbanking')}
                    />
                    <span className="custom-radio-dot"></span>
                    <span className="payment-method-name">Net Banking</span>
                  </label>

                  {paymentMethod === 'netbanking' && (
                    <div className="nested-payment-input-box">
                      <label>Select Your Bank</label>
                      <select
                        value={selectedBank}
                        onChange={(e) => setSelectedBank(e.target.value)}
                        className="bank-select-dropdown"
                      >
                        <option value="Chase Bank">Chase Bank</option>
                        <option value="Bank of America">Bank of America</option>
                        <option value="Wells Fargo">Wells Fargo</option>
                        <option value="HDFC Bank">HDFC Bank</option>
                        <option value="ICICI Bank">ICICI Bank</option>
                        <option value="State Bank of India">State Bank of India</option>
                      </select>
                    </div>
                  )}
                </div>

                {/* 4. Wallets / Cash on Delivery Option */}
                <div className={`payment-method-option-card ${paymentMethod === 'wallets' ? 'selected' : ''}`}>
                  <label className="payment-radio-label">
                    <input
                      type="radio"
                      name="paymentOption"
                      value="wallets"
                      checked={paymentMethod === 'wallets'}
                      onChange={() => setPaymentMethod('wallets')}
                    />
                    <span className="custom-radio-dot"></span>
                    <span className="payment-method-name">Wallets / Cash on Delivery</span>
                  </label>
                </div>
              </div>

              <div className="payment-actions-row">
                <button
                  type="button"
                  className="secondary-outline-btn"
                  onClick={() => setCurrentStep(1)}
                >
                  <ChevronLeftIcon size={16} />
                  <span>Back to Shipping</span>
                </button>

                <button
                  type="button"
                  className="checkout-action-dark-btn pay-now-btn"
                  onClick={handleContinueToReview}
                >
                  REVIEW & PAY ${total.toFixed(2)}
                </button>
              </div>
            </div>
          )}

          {/* STEP 3: REVIEW & CONFIRM */}
          {currentStep === 3 && (
            <div className="checkout-card-box">
              <h2 className="checkout-card-title">Review Your Order</h2>

              <div className="review-sections-grid">
                {/* Shipping Summary */}
                <div className="review-section-box">
                  <div className="review-box-header">
                    <h4>Shipping Destination</h4>
                    <button type="button" className="edit-step-btn" onClick={() => setCurrentStep(1)}>
                      Edit
                    </button>
                  </div>
                  <p className="review-text-bold">{shippingInfo.fullName}</p>
                  <p className="review-text-muted">{shippingInfo.address} {shippingInfo.suite}</p>
                  <p className="review-text-muted">{shippingInfo.city}, {shippingInfo.state} {shippingInfo.zipCode}</p>
                  <p className="review-text-muted">Phone: {shippingInfo.phone}</p>
                </div>

                {/* Payment Summary */}
                <div className="review-section-box">
                  <div className="review-box-header">
                    <h4>Payment Method</h4>
                    <button type="button" className="edit-step-btn" onClick={() => setCurrentStep(2)}>
                      Edit
                    </button>
                  </div>
                  <p className="review-text-bold capitalize">{paymentMethod === 'card' ? 'Credit / Debit Card' : paymentMethod}</p>
                  <p className="review-text-muted">
                    {paymentMethod === 'card' && 'Ending in •••• 4242'}
                    {paymentMethod === 'upi' && `VPA: ${upiId}`}
                    {paymentMethod === 'netbanking' && selectedBank}
                    {paymentMethod === 'wallets' && 'Cash on Delivery'}
                  </p>
                  <span className="secure-badge">🔒 256-Bit SSL Protected</span>
                </div>
              </div>

              {/* Items Summary in Step 3 */}
              <div className="review-items-list-box">
                <h4>Items in this order ({cartItems.length})</h4>
                <div className="mini-review-items">
                  {cartItems.map((item) => (
                    <div key={item.id} className="mini-review-row">
                      <img src={item.image} alt={item.name} className="mini-thumb" />
                      <div className="mini-info">
                        <strong>{item.name}</strong>
                        <span>Qty: {item.quantity} • {item.size} • {item.color}</span>
                      </div>
                      <div className="mini-price">
                        ${(item.price * item.quantity).toFixed(2)}
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="payment-actions-row mt-6">
                <button
                  type="button"
                  className="secondary-outline-btn"
                  onClick={() => setCurrentStep(2)}
                >
                  <ChevronLeftIcon size={16} />
                  <span>Back to Payment</span>
                </button>

                <button
                  type="button"
                  className="checkout-action-dark-btn pay-now-btn"
                  onClick={handlePlaceOrder}
                  disabled={isProcessingOrder}
                >
                  {isProcessingOrder ? 'Processing Payment...' : `PLACE ORDER ($${total.toFixed(2)})`}
                </button>
              </div>
            </div>
          )}
        </div>

        {/* Right Column: Live Order Summary matching Figma wireframe */}
        <aside className="checkout-summary-column">
          <div className="order-summary-card">
            <h3 className="summary-card-heading">Order Summary</h3>

            {/* Mini Items List matching Figma wireframe */}
            <div className="summary-mini-items-list">
              {cartItems.map((item) => (
                <div key={item.id} className="summary-item-tile">
                  <div className="tile-thumb-wrapper">
                    <img src={item.image} alt={item.name} className="tile-thumb" />
                    <span className="tile-qty-badge">{item.quantity}</span>
                  </div>
                  <div className="tile-details">
                    <h5 className="tile-title">{item.name}</h5>
                    <span className="tile-attrs">
                      {item.size} / {item.color}
                    </span>
                    <span className="tile-price">${Number(item.price).toFixed(2)}</span>
                  </div>
                </div>
              ))}
            </div>

            <div className="summary-pricing-breakdown">
              <div className="summary-line">
                <span>Subtotal</span>
                <span>${subtotal.toFixed(2)}</span>
              </div>
              {discountAmount > 0 && (
                <div className="summary-line discount-text">
                  <span>Discount</span>
                  <span>-${discountAmount.toFixed(2)}</span>
                </div>
              )}
              <div className="summary-line">
                <span>Shipping</span>
                <span>{shipping === 0 ? 'Free' : `$${shipping.toFixed(2)}`}</span>
              </div>
              <div className="summary-line">
                <span>Tax (6%)</span>
                <span>${tax.toFixed(2)}</span>
              </div>
              <div className="summary-divider"></div>
              <div className="summary-line grand-total-line">
                <span>Total</span>
                <span className="grand-total-val">${total.toFixed(2)}</span>
              </div>
            </div>
          </div>
        </aside>
      </div>
    </div>
  );
};
