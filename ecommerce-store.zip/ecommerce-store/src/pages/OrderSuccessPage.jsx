import React, { useState } from 'react';
import { useSearchParams, Link } from 'react-router-dom';
import { useOrder } from '../context/OrderContext';
import { Receipt } from '../components/Receipt';
import { CheckIcon, PrinterIcon, ChevronRightIcon } from '../components/Icons';

export const OrderSuccessPage = () => {
  const [searchParams] = useSearchParams();
  const orderId = searchParams.get('orderId');
  const { currentOrder, getOrderById } = useOrder();

  const [showFullReceipt, setShowFullReceipt] = useState(true);

  // Retrieve active order by ID or context
  const order = (orderId ? getOrderById(orderId) : currentOrder) || currentOrder;

  const handlePrint = () => {
    window.print();
  };

  return (
    <div className="order-success-page-container">
      {/* Figma Wireframe Confirmation Card */}
      <div className="order-placed-hero-card no-print">
        <div className="success-check-circle">
          <CheckIcon size={36} />
        </div>

        <h1 className="success-title">Thank you!</h1>
        <p className="success-subtitle">Your order has been placed successfully.</p>

        {order && (
          <div className="order-quick-id-badge">
            <span>Order Reference: <strong>{order.id}</strong></span>
          </div>
        )}

        <div className="success-actions-row">
          <button
            type="button"
            className="secondary-outline-btn"
            onClick={() => setShowFullReceipt(!showFullReceipt)}
          >
            {showFullReceipt ? 'HIDE RECEIPT' : 'VIEW ORDER'}
          </button>

          <button
            type="button"
            className="primary-dark-btn print-cta-btn"
            onClick={handlePrint}
          >
            <PrinterIcon size={18} />
            <span>PRINT RECEIPT</span>
          </button>
        </div>
      </div>

      {/* Embedded Printable Receipt matching Figma requirements */}
      {showFullReceipt && order && (
        <div className="receipt-view-wrapper">
          <Receipt order={order} onPrint={handlePrint} />
        </div>
      )}

      {/* Navigation Link Back */}
      <div className="success-footer-nav no-print">
        <Link to="/orders" className="secondary-outline-btn">
          View All Orders
        </Link>
        <Link to="/category" className="primary-btn">
          <span>Continue Shopping</span>
          <ChevronRightIcon size={16} />
        </Link>
      </div>
    </div>
  );
};
