import React from 'react';
import { Link } from 'react-router-dom';
import { useWishlist } from '../context/WishlistContext';
import { useCart } from '../context/CartContext';
import { HeartIcon, TrashIcon, CartIcon, StarIcon, ChevronRightIcon } from '../components/Icons';

export const WishlistPage = () => {
  const { wishlist, removeFromWishlist } = useWishlist();
  const { addToCart } = useCart();

  const handleMoveToCart = (product) => {
    addToCart(product, product.sizes?.[0] || 'M', product.colors?.[0]?.name || 'Standard', product.colors?.[0]?.hex || '#111827', 1);
    removeFromWishlist(product.id);
  };

  return (
    <div className="wishlist-page-container">
      <div className="section-header-row">
        <div>
          <h1 className="section-title-heading">My Wishlist</h1>
          <p className="section-sub-desc">Saved items you love. Move them to your cart before they run out of stock.</p>
        </div>
        <Link to="/category" className="primary-btn">
          <span>Explore More</span>
          <ChevronRightIcon size={16} />
        </Link>
      </div>

      {wishlist.length === 0 ? (
        <div className="empty-wishlist-card">
          <div className="empty-icon">❤️</div>
          <h3>Your Wishlist is Empty</h3>
          <p>Click the heart icon on any product to save items for later.</p>
          <Link to="/category" className="primary-btn mt-4">
            Discover Products
          </Link>
        </div>
      ) : (
        <div className="wishlist-items-grid">
          {wishlist.map((product) => {
            const mainImg = product.images?.[0] || product.image || '';
            return (
              <div key={product.id} className="wishlist-item-card">
                <div className="wishlist-image-frame">
                  <Link to={`/product/${product.id}`}>
                    <img src={mainImg} alt={product.name} className="wishlist-item-img" />
                  </Link>
                  <button
                    type="button"
                    className="wishlist-remove-float-btn"
                    onClick={() => removeFromWishlist(product.id)}
                    aria-label="Remove from wishlist"
                  >
                    <TrashIcon size={16} />
                  </button>
                </div>

                <div className="wishlist-info-box">
                  <span className="wishlist-cat-tag">{product.category}</span>
                  <h4 className="wishlist-item-title">
                    <Link to={`/product/${product.id}`}>{product.name}</Link>
                  </h4>

                  <div className="product-card-rating">
                    <div className="stars-group">
                      {[...Array(5)].map((_, i) => (
                        <StarIcon key={i} size={13} filled={i < Math.floor(product.rating || 4.5)} />
                      ))}
                    </div>
                    <span className="rating-number">{product.rating || 4.5}</span>
                  </div>

                  <div className="wishlist-price-row">
                    <span className="wishlist-price">${Number(product.price).toFixed(2)}</span>
                    {product.originalPrice && (
                      <span className="original-price">${Number(product.originalPrice).toFixed(2)}</span>
                    )}
                  </div>

                  <button
                    type="button"
                    className="move-to-cart-btn"
                    onClick={() => handleMoveToCart(product)}
                  >
                    <CartIcon size={16} />
                    <span>Move to Cart</span>
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
};
