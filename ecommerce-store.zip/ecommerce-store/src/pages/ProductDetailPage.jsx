import React, { useState, useEffect } from 'react';
import { useParams, Link, useNavigate } from 'react-router-dom';
import { products } from '../data/products';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { ProductCard } from '../components/ProductCard';
import {
  StarIcon,
  HeartIcon,
  MinusIcon,
  PlusIcon,
  CartIcon,
  CheckIcon,
  TruckIcon,
  ReturnIcon,
  ShieldIcon,
  ChevronRightIcon
} from '../components/Icons';

export const ProductDetailPage = () => {
  const { id } = useParams();
  const navigate = useNavigate();
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();

  // Find product by id or slug
  const product = products.find((p) => p.id === id || p.slug === id) || products[0];

  const [selectedImageIndex, setSelectedImageIndex] = useState(0);
  const [selectedColor, setSelectedColor] = useState(product.colors?.[0]?.name || 'Olive Green');
  const [selectedColorHex, setSelectedColorHex] = useState(product.colors?.[0]?.hex || '#556b2f');
  const [selectedSize, setSelectedSize] = useState(product.sizes?.[0] || 'M');
  const [quantity, setQuantity] = useState(1);
  const [activeTab, setActiveTab] = useState('description'); // 'description' | 'reviews' | 'shipping'
  const [isAdded, setIsAdded] = useState(false);

  // Review Form state
  const [reviewName, setReviewName] = useState('');
  const [reviewRating, setReviewRating] = useState(5);
  const [reviewText, setReviewText] = useState('');
  const [userReviews, setUserReviews] = useState([
    {
      id: 'rev-1',
      name: 'Michael T.',
      rating: 5,
      date: 'August 24, 2024',
      comment: 'Super soft material and accurate fit. Looks great both buttoned up or casual over a white tee.'
    },
    {
      id: 'rev-2',
      name: 'Jessica K.',
      rating: 4,
      date: 'August 18, 2024',
      comment: 'Loved the Olive Green shade! Washed twice with no fading or shrinking.'
    }
  ]);
  const [reviewSubmitted, setReviewSubmitted] = useState(false);

  // Reset image and selections when product changes
  useEffect(() => {
    setSelectedImageIndex(0);
    if (product.colors?.length) {
      setSelectedColor(product.colors[0].name);
      setSelectedColorHex(product.colors[0].hex);
    }
    if (product.sizes?.length) {
      setSelectedSize(product.sizes[0]);
    }
    setQuantity(1);
    window.scrollTo(0, 0);
  }, [product]);

  const isLiked = isInWishlist(product.id);
  const productImages = product.images && product.images.length > 0
    ? product.images
    : [product.image || 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80'];

  const handleAddToCart = () => {
    addToCart(product, selectedSize, selectedColor, selectedColorHex, quantity);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 2000);
  };

  const handleBuyNow = () => {
    addToCart(product, selectedSize, selectedColor, selectedColorHex, quantity);
    navigate('/checkout');
  };

  const handleAddReview = (e) => {
    e.preventDefault();
    if (!reviewName || !reviewText) return;

    const newRev = {
      id: `rev-${Date.now()}`,
      name: reviewName,
      rating: reviewRating,
      date: 'Just now',
      comment: reviewText
    };

    setUserReviews([newRev, ...userReviews]);
    setReviewName('');
    setReviewText('');
    setReviewSubmitted(true);
    setTimeout(() => setReviewSubmitted(false), 3000);
  };

  const relatedProducts = products
    .filter((p) => p.category === product.category && p.id !== product.id)
    .slice(0, 4);

  return (
    <div className="product-detail-page-container">
      {/* Breadcrumb Navigation matching Figma */}
      <div className="breadcrumbs-bar">
        <div className="breadcrumbs-content">
          <Link to="/" className="breadcrumb-link">Home</Link>
          <ChevronRightIcon size={14} className="breadcrumb-separator" />
          <Link to={`/category?cat=${product.category}`} className="breadcrumb-link capitalize">
            {product.category}
          </Link>
          {product.subCategory && (
            <>
              <ChevronRightIcon size={14} className="breadcrumb-separator" />
              <span className="breadcrumb-link">{product.subCategory}</span>
            </>
          )}
          <ChevronRightIcon size={14} className="breadcrumb-separator" />
          <span className="breadcrumb-current">{product.name}</span>
        </div>
      </div>

      {/* Main Product Layout */}
      <div className="product-main-grid">
        {/* Left: Gallery (Thumbnails + Main View) */}
        <div className="product-gallery-column">
          {/* Thumbnails list */}
          <div className="gallery-thumbnails-list">
            {productImages.map((imgUrl, idx) => (
              <button
                key={idx}
                type="button"
                className={`gallery-thumb-btn ${selectedImageIndex === idx ? 'active' : ''}`}
                onClick={() => setSelectedImageIndex(idx)}
              >
                <img src={imgUrl} alt={`${product.name} thumbnail ${idx + 1}`} />
              </button>
            ))}
          </div>

          {/* Large Main Image */}
          <div className="gallery-main-frame">
            <img
              src={productImages[selectedImageIndex]}
              alt={product.name}
              className="gallery-main-image"
            />
            {product.originalPrice && product.originalPrice > product.price && (
              <span className="gallery-discount-badge">
                {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
              </span>
            )}
          </div>
        </div>

        {/* Right: Product Purchase Details */}
        <div className="product-info-column">
          <div className="product-brand-subtitle">{product.brand || 'VELOUR SIGNATURE'}</div>
          <h1 className="product-main-heading">{product.name}</h1>

          {/* Rating Summary */}
          <div className="product-rating-summary">
            <div className="stars-group">
              {[...Array(5)].map((_, i) => (
                <StarIcon
                  key={i}
                  size={16}
                  filled={i < Math.floor(product.rating || 4.5)}
                />
              ))}
            </div>
            <span className="rating-score">{product.rating || 4.5}</span>
            <span className="rating-reviews-link" onClick={() => setActiveTab('reviews')}>
              ({product.reviewsCount || 98} verified reviews)
            </span>
          </div>

          {/* Price Block matching Figma */}
          <div className="product-price-block">
            <div className="price-values">
              <span className="price-current">${Number(product.price).toFixed(2)}</span>
              {product.originalPrice && (
                <span className="price-original">${Number(product.originalPrice).toFixed(2)}</span>
              )}
            </div>
            <span className="price-tax-note">Inclusive of all taxes</span>
          </div>

          {/* Description Snippet */}
          <p className="product-short-description">{product.shortDescription}</p>

          <div className="product-options-divider"></div>

          {/* Color Selector */}
          {product.colors && product.colors.length > 0 && (
            <div className="product-option-section">
              <div className="option-label-row">
                <span className="option-label">Color:</span>
                <span className="option-selected-name">{selectedColor}</span>
              </div>
              <div className="color-swatches-row">
                {product.colors.map((c) => (
                  <button
                    key={c.name}
                    type="button"
                    className={`color-selector-btn ${selectedColor === c.name ? 'active' : ''}`}
                    onClick={() => {
                      setSelectedColor(c.name);
                      setSelectedColorHex(c.hex);
                    }}
                    title={c.name}
                  >
                    <span className="color-fill-dot" style={{ backgroundColor: c.hex }} />
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Size Selector */}
          {product.sizes && product.sizes.length > 0 && (
            <div className="product-option-section">
              <div className="option-label-row">
                <span className="option-label">Size:</span>
                <button
                  type="button"
                  className="size-guide-link"
                  onClick={() => alert('Standard Size Chart: S (36"), M (38-40"), L (42"), XL (44"), XXL (46")')}
                >
                  Size Guide
                </button>
              </div>
              <div className="size-buttons-row">
                {product.sizes.map((s) => (
                  <button
                    key={s}
                    type="button"
                    className={`size-select-btn ${selectedSize === s ? 'active' : ''}`}
                    onClick={() => setSelectedSize(s)}
                  >
                    {s}
                  </button>
                ))}
              </div>
            </div>
          )}

          {/* Quantity Selector */}
          <div className="product-option-section">
            <span className="option-label">Quantity:</span>
            <div className="quantity-stepper large">
              <button
                type="button"
                className="qty-btn"
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                aria-label="Decrease Quantity"
              >
                <MinusIcon size={14} />
              </button>
              <span className="qty-value">{quantity}</span>
              <button
                type="button"
                className="qty-btn"
                onClick={() => setQuantity((q) => q + 1)}
                aria-label="Increase Quantity"
              >
                <PlusIcon size={14} />
              </button>
            </div>
          </div>

          {/* Action Buttons matching Figma wireframe */}
          <div className="product-actions-group">
            <button
              type="button"
              className={`primary-add-cart-btn ${isAdded ? 'added' : ''}`}
              onClick={handleAddToCart}
            >
              {isAdded ? (
                <>
                  <CheckIcon size={20} />
                  <span>ADDED TO CART</span>
                </>
              ) : (
                <>
                  <CartIcon size={20} />
                  <span>ADD TO CART</span>
                </>
              )}
            </button>

            <button
              type="button"
              className="secondary-buy-now-btn"
              onClick={handleBuyNow}
            >
              BUY NOW
            </button>

            <button
              type="button"
              className={`action-wishlist-btn ${isLiked ? 'active' : ''}`}
              onClick={() => toggleWishlist(product)}
              aria-label="Save to Wishlist"
              title="Save to Wishlist"
            >
              <HeartIcon size={20} filled={isLiked} className={isLiked ? 'text-red' : ''} />
            </button>
          </div>

          {/* Product Mini Trust Badges matching Figma */}
          <div className="product-trust-chips-row">
            <div className="trust-chip-item">
              <TruckIcon size={18} />
              <span>Free Shipping</span>
            </div>
            <div className="trust-chip-item">
              <ReturnIcon size={18} />
              <span>Easy Returns</span>
            </div>
            <div className="trust-chip-item">
              <ShieldIcon size={18} />
              <span>Secure Payment</span>
            </div>
          </div>
        </div>
      </div>

      {/* Tabs Section matching Figma wireframe: DESCRIPTION / REVIEWS (98) / SHIPPING & RETURNS */}
      <div className="product-tabs-section">
        <div className="tabs-header-nav">
          <button
            className={`tab-nav-btn ${activeTab === 'description' ? 'active' : ''}`}
            onClick={() => setActiveTab('description')}
          >
            DESCRIPTION
          </button>
          <button
            className={`tab-nav-btn ${activeTab === 'reviews' ? 'active' : ''}`}
            onClick={() => setActiveTab('reviews')}
          >
            REVIEWS ({userReviews.length + (product.reviewsCount || 98)})
          </button>
          <button
            className={`tab-nav-btn ${activeTab === 'shipping' ? 'active' : ''}`}
            onClick={() => setActiveTab('shipping')}
          >
            SHIPPING & RETURNS
          </button>
        </div>

        <div className="tab-panel-content">
          {/* Tab 1: Description */}
          {activeTab === 'description' && (
            <div className="description-panel">
              <p className="desc-lead-text">{product.shortDescription}</p>

              {product.features && (
                <div className="features-bullet-list">
                  <h4>Key Highlights & Features:</h4>
                  <ul>
                    {product.features.map((feat, i) => (
                      <li key={i}>{feat}</li>
                    ))}
                  </ul>
                </div>
              )}

              {product.details && (
                <div className="specifications-table-wrapper">
                  <h4>Product Specifications:</h4>
                  <div className="specs-grid">
                    <div className="spec-row">
                      <span className="spec-name">Material</span>
                      <span className="spec-val">{product.details.material}</span>
                    </div>
                    <div className="spec-row">
                      <span className="spec-name">Fit Profile</span>
                      <span className="spec-val">{product.details.fit}</span>
                    </div>
                    <div className="spec-row">
                      <span className="spec-name">Care Instructions</span>
                      <span className="spec-val">{product.details.care}</span>
                    </div>
                    <div className="spec-row">
                      <span className="spec-name">Country of Origin</span>
                      <span className="spec-val">{product.details.origin}</span>
                    </div>
                  </div>
                </div>
              )}
            </div>
          )}

          {/* Tab 2: Reviews */}
          {activeTab === 'reviews' && (
            <div className="reviews-panel">
              <div className="reviews-breakdown-row">
                <div className="reviews-score-card">
                  <div className="big-rating-number">{product.rating || 4.5}</div>
                  <div className="stars-group">
                    {[...Array(5)].map((_, i) => (
                      <StarIcon key={i} size={18} filled={i < Math.floor(product.rating || 4.5)} />
                    ))}
                  </div>
                  <p className="score-total-count">Based on {userReviews.length + 98} verified ratings</p>
                </div>

                {/* Write Review Form */}
                <div className="write-review-card">
                  <h4>Write a Customer Review</h4>
                  {reviewSubmitted ? (
                    <div className="review-success-badge">
                      <CheckIcon size={20} />
                      <span>Thank you! Your verified review has been published.</span>
                    </div>
                  ) : (
                    <form onSubmit={handleAddReview}>
                      <div className="form-group-field">
                        <label>Your Name</label>
                        <input
                          type="text"
                          placeholder="e.g. Sarah Jenkins"
                          value={reviewName}
                          onChange={(e) => setReviewName(e.target.value)}
                          required
                        />
                      </div>
                      <div className="form-group-field">
                        <label>Rating</label>
                        <div className="star-rating-select">
                          {[1, 2, 3, 4, 5].map((num) => (
                            <button
                              key={num}
                              type="button"
                              className="star-rate-btn"
                              onClick={() => setReviewRating(num)}
                            >
                              <StarIcon size={22} filled={num <= reviewRating} />
                            </button>
                          ))}
                        </div>
                      </div>
                      <div className="form-group-field">
                        <label>Review Comment</label>
                        <textarea
                          rows={3}
                          placeholder="How did this product fit and feel? Share your feedback..."
                          value={reviewText}
                          onChange={(e) => setReviewText(e.target.value)}
                          required
                        />
                      </div>
                      <button type="submit" className="primary-btn">
                        Submit Review
                      </button>
                    </form>
                  )}
                </div>
              </div>

              {/* Reviews List */}
              <div className="customer-reviews-stream">
                <h4>Recent Verified Reviews</h4>
                <div className="reviews-items-list">
                  {userReviews.map((rev) => (
                    <div key={rev.id} className="review-stream-item">
                      <div className="review-stream-header">
                        <div className="user-initial-badge">{rev.name.charAt(0)}</div>
                        <div>
                          <strong>{rev.name}</strong>
                          <span className="review-date-text">{rev.date}</span>
                        </div>
                        <div className="stars-group ml-auto">
                          {[...Array(5)].map((_, i) => (
                            <StarIcon key={i} size={14} filled={i < rev.rating} />
                          ))}
                        </div>
                      </div>
                      <p className="review-stream-comment">{rev.comment}</p>
                    </div>
                  ))}
                </div>
              </div>
            </div>
          )}

          {/* Tab 3: Shipping & Returns */}
          {activeTab === 'shipping' && (
            <div className="shipping-panel">
              <div className="shipping-info-grid">
                <div className="shipping-card-info">
                  <h4>📦 Fast Worldwide Shipping</h4>
                  <p>Standard delivery arrives in 2–4 business days. Free shipping is automatically applied to all orders above $50.00.</p>
                </div>
                <div className="shipping-card-info">
                  <h4>🔄 30-Day Hassle-Free Returns</h4>
                  <p>If you're not completely satisfied with fit or style, return your unworn items within 30 days for a full refund or exchange.</p>
                </div>
                <div className="shipping-card-info">
                  <h4>🔒 100% Insured Delivery</h4>
                  <p>All packages are insured against loss or transit damage with end-to-end real-time tracking updates.</p>
                </div>
              </div>
            </div>
          )}
        </div>
      </div>

      {/* Related Products Showcase */}
      {relatedProducts.length > 0 && (
        <section className="related-products-section">
          <div className="section-header-row">
            <h2 className="section-title-heading">You May Also Like</h2>
            <Link to={`/category?cat=${product.category}`} className="view-all-link">
              <span>View All</span>
              <ChevronRightIcon size={16} />
            </Link>
          </div>
          <div className="products-grid-layout">
            {relatedProducts.map((rel) => (
              <ProductCard key={rel.id} product={rel} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
};
