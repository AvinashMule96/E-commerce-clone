import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useOrder } from '../context/OrderContext';
import { Receipt } from '../components/Receipt';
import { PrinterIcon, ChevronRightIcon, CloseIcon } from '../components/Icons';

export const OrdersHistoryPage = () => {
  const { orders } = useOrder();
  const [selectedReceiptOrder, setSelectedReceiptOrder] = useState(null);

  return (
    <div className="orders-history-page-container">
      <div className="section-header-row">
        <div>
          <h1 className="section-title-heading">My Orders</h1>
          <p className="section-sub-desc">Track real-time shipment status and view printable tax invoices.</p>
        </div>
        <Link to="/category" className="primary-btn">
          <span>Continue Shopping</span>
          <ChevronRightIcon size={16} />
        </Link>
      </div>

      {orders.length === 0 ? (
        <div className="empty-orders-card">
          <div className="empty-icon">📦</div>
          <h3>No Orders Placed Yet</h3>
          <p>When you complete a purchase, your order history and printable tax receipts will appear here.</p>
          <Link to="/category" className="primary-btn mt-4">
            Start Shopping
          </Link>
        </div>
      ) : (
        <div className="orders-cards-list">
          {orders.map((order) => (
            <div key={order.id} className="order-history-card">
              {/* Order Card Header */}
              <div className="order-card-header-bar">
                <div className="order-meta-left">
                  <div className="order-id-label">
                    Order <strong>{order.id}</strong>
                  </div>
                  <span className="order-date-text">{order.dateString}</span>
                </div>

                <div className="order-meta-right">
                  <span className="order-status-badge">● {order.status}</span>
                  <button
                    type="button"
                    className="view-receipt-btn"
                    onClick={() => setSelectedReceiptOrder(order)}
                  >
                    <PrinterIcon size={16} />
                    <span>View / Print Receipt</span>
                  </button>
                </div>
              </div>

              {/* Order Items Row */}
              <div className="order-items-thumbnails-row">
                <div className="thumbnails-wrapper">
                  {order.items?.map((item, idx) => (
                    <div key={idx} className="order-thumb-item" title={`${item.name} (x${item.quantity})`}>
                      <img src={item.image} alt={item.name} className="order-thumb-img" />
                      <span className="thumb-item-qty">{item.quantity}</span>
                    </div>
                  ))}
                </div>

                <div className="order-pricing-summary-col">
                  <span className="total-items-count">
                    {order.items?.reduce((acc, it) => acc + it.quantity, 0)} Items
                  </span>
                  <span className="order-total-price-text">
                    Total: <strong>${Number(order.pricing?.total || 0).toFixed(2)}</strong>
                  </span>
                </div>
              </div>
            </div>
          ))}
        </div>
      )}

      {/* Modal View for Receipt */}
      {selectedReceiptOrder && (
        <div className="modal-overlay" onClick={() => setSelectedReceiptOrder(null)}>
          <div className="modal-receipt-container" onClick={(e) => e.stopPropagation()}>
            <div className="modal-receipt-header no-print">
              <h3>Order Receipt - {selectedReceiptOrder.id}</h3>
              <button
                className="close-modal-btn"
                onClick={() => setSelectedReceiptOrder(null)}
                aria-label="Close Receipt Modal"
              >
                <CloseIcon size={20} />
              </button>
            </div>
            <div className="modal-receipt-body">
              <Receipt order={selectedReceiptOrder} />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
