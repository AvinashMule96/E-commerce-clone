export const testimonials = [
  {
    id: 1,
    name: 'Sarah Jenkins',
    role: 'Verified Buyer',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1494790108377-be9c29b29330?auto=format&fit=crop&w=150&q=80',
    comment: 'The casual cotton shirt fits like a dream! The fabric is ultra soft, breathable, and holds up nicely after repeated washing. Shipping was lightning fast too.',
    date: '2 days ago',
    productPurchased: 'Casual Cotton Shirt'
  },
  {
    id: 2,
    name: 'David Miller',
    role: 'Verified Buyer',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?auto=format&fit=crop&w=150&q=80',
    comment: 'Exceptional quality on the Running Shoes. Super light, plenty of arch support for 10k runs, and the minimalist aesthetic looks great with jeans.',
    date: '1 week ago',
    productPurchased: 'Running Shoes'
  },
  {
    id: 3,
    name: 'Elena Rostova',
    role: 'Verified Buyer',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1534528741775-53994a69daeb?auto=format&fit=crop&w=150&q=80',
    comment: 'The checkout experience was seamless. Received my Minimalist Leather Watch in pristine packaging with an official warranty card. Highly recommended!',
    date: '2 weeks ago',
    productPurchased: 'Minimalist Leather Watch'
  },
  {
    id: 4,
    name: 'Marcus Vance',
    role: 'Verified Buyer',
    rating: 5,
    avatar: 'https://images.unsplash.com/photo-1500648767791-00dcc994a43e?auto=format&fit=crop&w=150&q=80',
    comment: 'The Urban Canvas Backpack easily fits my 16" laptop, tech cables, and gym gear with plenty of room to spare. Sturdy waxed canvas and durable zippers.',
    date: '3 weeks ago',
    productPurchased: 'Urban Canvas Backpack'
  }
];

export const bookingTimeSlots = [
  { id: 't1', time: '10:00 AM', available: true },
  { id: 't2', time: '11:30 AM', available: true },
  { id: 't3', time: '01:00 PM', available: true },
  { id: 't4', time: '02:30 PM', available: true },
  { id: 't5', time: '04:00 PM', available: true },
  { id: 't6', time: '05:30 PM', available: true }
];

export const initialChatMessages = [
  {
    id: 'msg-1',
    sender: 'agent',
    text: 'Hi! How can we help you today?',
    time: '10:30 AM'
  },
  {
    id: 'msg-2',
    sender: 'user',
    text: 'I have a question about my order delivery timeline.',
    time: '10:32 AM'
  },
  {
    id: 'msg-3',
    sender: 'agent',
    text: 'Sure! Please share your Order ID or email address and our support specialist will pull up the tracking details immediately.',
    time: '10:33 AM'
  }
];
