export const categories = [
  {
    id: 'men',
    name: 'Men',
    slug: 'men',
    count: 38,
    image: 'https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?auto=format&fit=crop&w=600&q=80',
    description: 'Elevated essentials, shirts, t-shirts, denim, and outerwear for men.'
  },
  {
    id: 'women',
    name: 'Women',
    slug: 'women',
    count: 46,
    image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=600&q=80',
    description: 'Chic silhouettes, dresses, tops, tailored trousers, and knitwear.'
  },
  {
    id: 'footwear',
    name: 'Footwear',
    slug: 'footwear',
    count: 24,
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80',
    description: 'Performance running shoes, minimalist leather sneakers, and boots.'
  },
  {
    id: 'bags',
    name: 'Bags',
    slug: 'bags',
    count: 19,
    image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=600&q=80',
    description: 'Canvas backpacks, leather crossbodies, tote bags, and luggage.'
  },
  {
    id: 'watches',
    name: 'Watches',
    slug: 'watches',
    count: 15,
    image: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=600&q=80',
    description: 'Timeless analog chronographs, minimal dials, and luxury straps.'
  },
  {
    id: 'electronics',
    name: 'Electronics',
    slug: 'electronics',
    count: 22,
    image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80',
    description: 'Noise-cancelling headphones, wireless chargers, and smart gadgets.'
  },
  {
    id: 'home-living',
    name: 'Home & Living',
    slug: 'home-living',
    count: 18,
    image: 'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=600&q=80',
    description: 'Modern ceramic vases, scented soy candles, and textured throws.'
  },
  {
    id: 'beauty',
    name: 'Beauty',
    slug: 'beauty',
    count: 14,
    image: 'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=600&q=80',
    description: 'Botanical skincare, hydrating serums, and cruelty-free wellness.'
  },
  {
    id: 'deals',
    name: 'Deals',
    slug: 'deals',
    count: 28,
    image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=600&q=80',
    description: 'Exclusive seasonal discounts up to 50% off select bestsellers.'
  }
];
