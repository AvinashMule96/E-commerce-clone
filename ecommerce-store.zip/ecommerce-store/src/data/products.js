export const products = [
  {
    id: 'prod-1',
    name: 'Casual Cotton Shirt',
    slug: 'casual-cotton-shirt',
    category: 'men',
    subCategory: 'Shirts',
    brand: "Levi's",
    price: 29.99,
    originalPrice: 39.99,
    rating: 4.5,
    reviewsCount: 98,
    isBestSeller: true,
    isFeatured: true,
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1598033129183-c4f50c736f10?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1521572267360-ee0c2909d518?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Olive Green', hex: '#556b2f' },
      { name: 'Navy Blue', hex: '#1e3a8a' },
      { name: 'Onyx Black', hex: '#111827' },
      { name: 'Cloud White', hex: '#f3f4f6' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    shortDescription: 'This casual cotton shirt is made from 100% premium cotton fabric. It is soft, breathable, and ideal for everyday wear.',
    features: [
      'Regular Fit tailored for effortless comfort',
      'Button-down collar with structured stitching',
      'Full sleeves with adjustable two-button cuffs',
      'Available in versatile earthy colors and full size range',
      'Pre-shrunk fabric to retain shape after wash'
    ],
    details: {
      material: '100% Organic Ring-Spun Cotton',
      fit: 'Regular Fit',
      care: 'Machine wash cold with like colors, tumble dry low, warm iron if needed',
      origin: 'Ethically crafted in Portugal'
    }
  },
  {
    id: 'prod-2',
    name: 'Running Shoes',
    slug: 'running-shoes',
    category: 'footwear',
    subCategory: 'Sneakers',
    brand: 'Nike',
    price: 59.99,
    originalPrice: 79.99,
    rating: 4.8,
    reviewsCount: 142,
    isBestSeller: true,
    isFeatured: true,
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1606107557195-0e29a4b5b4aa?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1551107696-a4b0c5a0d9a2?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Black', hex: '#111827' },
      { name: 'Charcoal Gray', hex: '#4b5563' },
      { name: 'Pure White', hex: '#ffffff' }
    ],
    sizes: ['7', '8', '9', '10', '11', '12'],
    shortDescription: 'Ultralight performance running shoes designed for high energy return, breathable mesh ventilation, and all-day cushioning.',
    features: [
      'Engineered air mesh upper for maximum airflow',
      'High-rebound foam midsole absorbs heavy impacts',
      'Durable rubber outsole with multi-directional traction grips',
      'Padded ankle collar prevents chafing'
    ],
    details: {
      material: 'Recycled Polymer Mesh & EVA Sole',
      fit: 'True to Size',
      care: 'Spot clean with mild soapy water and soft brush',
      origin: 'Imported'
    }
  },
  {
    id: 'prod-3',
    name: 'Classic Slim Fit Denim',
    slug: 'classic-slim-fit-denim',
    category: 'men',
    subCategory: 'Jeans',
    brand: "Levi's",
    price: 49.99,
    originalPrice: 65.00,
    rating: 4.6,
    reviewsCount: 84,
    isBestSeller: true,
    isFeatured: false,
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1542272604-780c96856592?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1582552938357-32b906df40cb?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1475178626620-a4d074967452?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Indigo Blue', hex: '#1e3a8a' },
      { name: 'Washed Black', hex: '#374151' },
      { name: 'Light Blue', hex: '#93c5fd' }
    ],
    sizes: ['30', '32', '34', '36', '38'],
    shortDescription: 'Modern slim fit jeans crafted with comfort-stretch denim that moves naturally with your daily routine.',
    features: [
      'Slim cut through hip and thigh with a tapered leg',
      'Comfort-stretch denim for flexibility',
      'Signature 5-pocket styling and antique brass hardware',
      'Reinforced bar-tack stitching at stress points'
    ],
    details: {
      material: '98% Cotton, 2% Elastane',
      fit: 'Slim Fit',
      care: 'Turn inside out and wash cold, hang dry',
      origin: 'Crafted in Mexico'
    }
  },
  {
    id: 'prod-4',
    name: 'Minimalist Leather Watch',
    slug: 'minimalist-leather-watch',
    category: 'watches',
    subCategory: 'Analog',
    brand: 'Fossil',
    price: 89.99,
    originalPrice: 120.00,
    rating: 4.9,
    reviewsCount: 116,
    isBestSeller: true,
    isFeatured: true,
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1522335789203-aabd1fc54bc9?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1533139502658-0198f920d8e8?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1509042239860-f550ce710b93?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Cognac Tan', hex: '#854d0e' },
      { name: 'Midnight Black', hex: '#111827' },
      { name: 'Silver Steel', hex: '#9ca3af' }
    ],
    sizes: ['40mm'],
    shortDescription: 'Sophisticated minimalist timepiece featuring a Japanese quartz movement, clean matte dial, and genuine Italian leather strap.',
    features: [
      'Precision 3-hand Japanese quartz movement',
      'Scratch-resistant sapphire-coated mineral crystal',
      'Water resistant to 5 ATM (50 meters)',
      'Interchangeable quick-release genuine leather strap'
    ],
    details: {
      material: '316L Stainless Steel Case & Italian Leather',
      fit: 'Unisex 40mm case',
      care: 'Wipe case with dry microfiber cloth, avoid soaking leather',
      origin: 'Designed in Copenhagen'
    }
  },
  {
    id: 'prod-5',
    name: 'Urban Canvas Backpack',
    slug: 'urban-canvas-backpack',
    category: 'bags',
    subCategory: 'Backpacks',
    brand: 'Puma',
    price: 45.00,
    originalPrice: 60.00,
    rating: 4.7,
    reviewsCount: 65,
    isBestSeller: true,
    isFeatured: false,
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1553062407-98eeb64c6a62?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1622560480605-d83c853bc5c3?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1577733966973-d680bffd2e80?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Olive Green', hex: '#556b2f' },
      { name: 'Charcoal', hex: '#374151' },
      { name: 'Sand Khaki', hex: '#d4a373' }
    ],
    sizes: ['20 Liters'],
    shortDescription: 'Heavy-duty waxed canvas backpack equipped with padded laptop compartment, water-repellent finish, and ergonomic shoulder straps.',
    features: [
      'Dedicated padded sleeve fits up to 16" MacBook Pro',
      'Water-repellent 16oz cotton duck canvas',
      'Padded breathable mesh back panel for lumbar comfort',
      'Internal organizer pockets for keys, pens, and chargers'
    ],
    details: {
      material: 'Heavyweight Waxed Canvas & Full-Grain Leather Accents',
      fit: '20L Capacity (17.5" x 12" x 6")',
      care: 'Wipe clean with damp cloth, do not machine wash',
      origin: 'Imported'
    }
  },
  {
    id: 'prod-6',
    name: 'Wireless ANC Headphones',
    slug: 'wireless-anc-headphones',
    category: 'electronics',
    subCategory: 'Audio',
    brand: 'Adidas',
    price: 99.99,
    originalPrice: 149.99,
    rating: 4.8,
    reviewsCount: 180,
    isBestSeller: true,
    isFeatured: true,
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1484704849700-f032a568e944?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1546435770-a3e426bf472b?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1583394838336-acd977736f90?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Matte Black', hex: '#111827' },
      { name: 'Silver White', hex: '#e5e7eb' },
      { name: 'Navy', hex: '#1e3a8a' }
    ],
    sizes: ['Standard'],
    shortDescription: 'Studio-grade over-ear wireless headphones with hybrid Active Noise Cancellation and 40-hour battery life.',
    features: [
      'Hybrid ANC with ambient transparency awareness mode',
      '40mm high-fidelity custom dynamic neodymium drivers',
      'Up to 40 hours playback on a single charge; 10-min fast charge gives 4 hours',
      'Ultra-soft memory foam ear cushions for fatigue-free listening'
    ],
    details: {
      material: 'Anodized Aluminum & Memory Foam',
      fit: 'Over-ear adjustable headband',
      care: 'Wipe ear cushions with dry cloth, store in hardshell travel case',
      origin: 'Engineered in Germany'
    }
  },
  {
    id: 'prod-7',
    name: 'Structured Linen Blazer',
    slug: 'structured-linen-blazer',
    category: 'women',
    subCategory: 'Jackets',
    brand: 'Zara',
    price: 79.99,
    originalPrice: 110.00,
    rating: 4.6,
    reviewsCount: 52,
    isBestSeller: false,
    isFeatured: true,
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1584273143981-41c073dfe8f8?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1539109136881-3be0616acf4b?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1515886657613-9f3515b0c78f?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1509631179647-0177331693ae?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Natural Beige', hex: '#d4b996' },
      { name: 'Charcoal Black', hex: '#1f2937' },
      { name: 'Pastel Sage', hex: '#84a98c' }
    ],
    sizes: ['XS', 'S', 'M', 'L', 'XL'],
    shortDescription: 'Tailored single-breasted blazer woven from breathable European flax linen with a relaxed silhouette and horn buttons.',
    features: [
      'Relaxed tailored fit with subtle shoulder pads',
      'Notch lapel and single front button closure',
      'Dual flap front pockets and internal chest pocket',
      'Partially lined in lightweight viscose for summer breathability'
    ],
    details: {
      material: '100% French Flax Linen',
      fit: 'Relaxed Tailored',
      care: 'Dry clean only',
      origin: 'Made in Italy'
    }
  },
  {
    id: 'prod-8',
    name: 'Signature Polo Shirt',
    slug: 'signature-polo-shirt',
    category: 'men',
    subCategory: 'Polos',
    brand: 'U.S. Polo',
    price: 34.99,
    originalPrice: 48.00,
    rating: 4.4,
    reviewsCount: 77,
    isBestSeller: false,
    isFeatured: false,
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1586363104862-3a5e2ab60d99?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1625910513413-56272b5368a5?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1576566588028-4147f3842f27?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1618354691373-d851c5c3a990?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Navy Blue', hex: '#1e3a8a' },
      { name: 'Crimson Red', hex: '#991b1b' },
      { name: 'Pure White', hex: '#f9fafb' },
      { name: 'Forest Green', hex: '#14532d' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    shortDescription: 'Timeless piqué cotton polo with ribbed collar and signature embroidered crest on the chest.',
    features: [
      'Classic fit with side vent hem for ease of movement',
      'Heavyweight 220 GSM breathable cotton piqué',
      'Two-button mother-of-pearl placket',
      'Ribbed knit collar and sleeve bands that resist curling'
    ],
    details: {
      material: '100% Pima Cotton Piqué',
      fit: 'Classic Fit',
      care: 'Machine wash cold, reshape and dry flat',
      origin: 'Made in Peru'
    }
  },
  {
    id: 'prod-9',
    name: 'Leather Crossbody Bag',
    slug: 'leather-crossbody-bag',
    category: 'bags',
    subCategory: 'Handbags',
    brand: 'Zara',
    price: 64.99,
    originalPrice: 85.00,
    rating: 4.7,
    reviewsCount: 63,
    isBestSeller: true,
    isFeatured: false,
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1590874103328-eac38a683ce7?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1566150905458-1bf1fc113f0d?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1591561954557-26941169b49e?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Chestnut Brown', hex: '#78350f' },
      { name: 'Pitch Black', hex: '#111827' },
      { name: 'Warm Taupe', hex: '#a8a29e' }
    ],
    sizes: ['Medium'],
    shortDescription: 'Structured grain leather crossbody featuring gold-toned lock closure, interior slip pockets, and adjustable shoulder strap.',
    features: [
      'Supple full-grain pebble leather with gold hardware',
      'Magnetic flap closure with secure zip compartment inside',
      'Adjustable strap for over-the-shoulder or crossbody wear',
      'Sleek compact size for smartphone, wallet, and essentials'
    ],
    details: {
      material: '100% Top-Grain Cowhide Leather & Microfiber Lining',
      fit: '9" W x 6.5" H x 3" D',
      care: 'Condition with leather balm biannually',
      origin: 'Handcrafted in Spain'
    }
  },
  {
    id: 'prod-10',
    name: 'Hydrating Botanical Facial Serum',
    slug: 'hydrating-botanical-facial-serum',
    category: 'beauty',
    subCategory: 'Skincare',
    brand: 'H&M',
    price: 24.99,
    originalPrice: 32.00,
    rating: 4.9,
    reviewsCount: 110,
    isBestSeller: false,
    isFeatured: true,
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1620916566398-39f1143ab7be?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1608248597359-009f45d9e5ef?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1522337360788-8b13dee7a37e?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1556228720-195a672e8a03?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Clear Glass', hex: '#e2e8f0' }
    ],
    sizes: ['30ml / 1.0 fl oz'],
    shortDescription: 'Potent antioxidant serum with multi-molecular hyaluronic acid, niacinamide, and botanical rosehip oil for plump, glowing skin.',
    features: [
      'Triple-weight Hyaluronic Acid locks in moisture deeply',
      '5% Niacinamide refines pore texture and balances oil',
      'Cruelty-free, vegan, fragrance-free, and dermatologically tested',
      'Fast-absorbing, non-greasy silky finish'
    ],
    details: {
      material: 'Hyaluronic Acid, Vitamin B5, Rosa Canina Seed Extract',
      fit: '30ml Dropper Bottle',
      care: 'Store in a cool, dry place away from direct sunlight',
      origin: 'Formulated in France'
    }
  },
  {
    id: 'prod-11',
    name: 'Sculpted Ceramic Vase',
    slug: 'sculpted-ceramic-vase',
    category: 'home-living',
    subCategory: 'Decor',
    brand: 'Zara',
    price: 39.99,
    originalPrice: 50.00,
    rating: 4.8,
    reviewsCount: 39,
    isBestSeller: false,
    isFeatured: false,
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1578749556568-bc2c40e68b61?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1612196808214-b8e1d6145a8c?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1581783342308-f792dbdd27c5?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1513694203232-719a280e022f?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Matte Sand', hex: '#e7dfd5' },
      { name: 'Terracotta', hex: '#c86d51' },
      { name: 'Charcoal', hex: '#27272a' }
    ],
    sizes: ['10" Height'],
    shortDescription: 'Handcrafted stoneware vase with organic curved geometric profile and tactile matte textured finish for modern interiors.',
    features: [
      'Hand-thrown durable stoneware clay',
      'Waterproof glazed interior holds fresh floral stems',
      'Velveteen padded base protects delicate furniture tops',
      'Architectural statement piece for tables and mantels'
    ],
    details: {
      material: '100% Stoneware Ceramic',
      fit: '10" H x 6" W',
      care: 'Hand wash with warm water and dry with soft towel',
      origin: 'Handmade in Portugal'
    }
  },
  {
    id: 'prod-12',
    name: 'Sport Training Hoodie',
    slug: 'sport-training-hoodie',
    category: 'men',
    subCategory: 'Sweatshirts',
    brand: 'Nike',
    price: 54.99,
    originalPrice: 70.00,
    rating: 4.7,
    reviewsCount: 124,
    isBestSeller: true,
    isFeatured: false,
    inStock: true,
    images: [
      'https://images.unsplash.com/photo-1556905055-8f358a7a47b2?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1509967419530-da38b4704bc6?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1578587018452-892bacefd3f2?auto=format&fit=crop&w=800&q=80',
      'https://images.unsplash.com/photo-1543163521-1bf539c55dd2?auto=format&fit=crop&w=800&q=80'
    ],
    colors: [
      { name: 'Heather Gray', hex: '#9ca3af' },
      { name: 'Obsidian Black', hex: '#111827' },
      { name: 'Deep Olive', hex: '#3f4e3c' }
    ],
    sizes: ['S', 'M', 'L', 'XL', 'XXL'],
    shortDescription: 'Heavyweight fleece hoodie with thermal brushed interior, kangaroo pocket, and drawcord adjustable hood.',
    features: [
      'Warm 380 GSM fleece cotton-poly blend',
      'Double-lined hood with metal eyelets and drawstring',
      'Spacious kangaroo pocket with concealed headphone port',
      'Heavy ribbed cuffs and waistband for shape retention'
    ],
    details: {
      material: '80% Cotton, 20% Polyester Fleece',
      fit: 'Athletic Regular Fit',
      care: 'Machine wash warm, tumble dry low',
      origin: 'Imported'
    }
  }
];
