const API_BASE_URL = typeof window !== 'undefined' 
  ? (window.location.origin.includes('localhost') ? `${window.location.origin}/api` : '/api')
  : 'http://localhost:3000/api';

const request = async (endpoint, options = {}) => {
  try {
    const res = await fetch(`${API_BASE_URL}${endpoint}`, {
      headers: {
        'Content-Type': 'application/json',
        ...(options.headers || {})
      },
      ...options
    });
    return await res.json();
  } catch (err) {
    console.error(`API Error on ${endpoint}:`, err);
    return { success: false, error: err.message };
  }
};

export const api = {
  // Authentication
  auth: {
    login: (email, password) => 
      request('/auth/login', { method: 'POST', body: JSON.stringify({ email, password }) }),
    register: (name, email, password, phone) => 
      request('/auth/register', { method: 'POST', body: JSON.stringify({ name, email, password, phone }) }),
    getProfile: () => request('/auth/me')
  },

  // Categories & Products
  categories: {
    getAll: () => request('/categories')
  },
  products: {
    getAll: (params = {}) => {
      const queryString = new URLSearchParams(params).toString();
      return request(`/products${queryString ? `?${queryString}` : ''}`);
    },
    getById: (id) => request(`/products/${id}`),
    addReview: (id, name, rating, comment) => 
      request(`/products/${id}/reviews`, { method: 'POST', body: JSON.stringify({ name, rating, comment }) })
  },

  // Cart
  cart: {
    get: () => request('/cart'),
    add: (productId, size = 'M', color = 'Standard', quantity = 1) => 
      request('/cart/items', { method: 'POST', body: JSON.stringify({ productId, size, color, quantity }) }),
    updateQuantity: (id, quantity) => 
      request(`/cart/items/${id}`, { method: 'PUT', body: JSON.stringify({ quantity }) }),
    removeItem: (id) => 
      request(`/cart/items/${id}`, { method: 'DELETE' }),
    clear: () => 
      request('/cart', { method: 'DELETE' }),
    applyCoupon: (code) => 
      request('/cart/coupon', { method: 'POST', body: JSON.stringify({ code }) })
  },

  // Orders
  orders: {
    create: (orderData) => 
      request('/orders', { method: 'POST', body: JSON.stringify(orderData) }),
    getAll: () => request('/orders'),
    getById: (id) => request(`/orders/${id}`)
  },

  // Styling Appointments
  bookings: {
    getSlots: () => request('/bookings/slots'),
    create: (bookingData) => 
      request('/bookings', { method: 'POST', body: JSON.stringify(bookingData) })
  },

  // Support & Chat
  support: {
    contact: (name, email, message) => 
      request('/support/contact', { method: 'POST', body: JSON.stringify({ name, email, message }) }),
    chat: (message) => 
      request('/support/chat', { method: 'POST', body: JSON.stringify({ message }) })
  }
};

export default api;
