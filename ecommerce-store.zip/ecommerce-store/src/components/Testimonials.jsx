import React, { useState } from 'react';
import { testimonials } from '../data/testimonials';
import { StarIcon, ChevronLeftIcon, ChevronRightIcon } from './Icons';

export const Testimonials = () => {
  const [currentIndex, setCurrentIndex] = useState(0);

  const nextTestimonial = () => {
    setCurrentIndex((prev) => (prev + 1) % testimonials.length);
  };

  const prevTestimonial = () => {
    setCurrentIndex((prev) => (prev - 1 + testimonials.length) % testimonials.length);
  };

  return (
    <section className="testimonials-section">
      <div className="section-header-center">
        <span className="section-sub-tag">TESTIMONIALS</span>
        <h2 className="section-title-heading">What Our Customers Say</h2>
        <p className="section-sub-desc">Real experiences from our verified community of happy shoppers worldwide.</p>
      </div>

      <div className="testimonials-container">
        <div className="testimonials-grid">
          {testimonials.map((item, idx) => (
            <div
              key={item.id}
              className={`testimonial-card ${idx === currentIndex ? 'highlighted' : ''}`}
            >
              <div className="testimonial-header">
                <img
                  src={item.avatar}
                  alt={item.name}
                  className="testimonial-avatar-img"
                  loading="lazy"
                />
                <div className="testimonial-user-meta">
                  <h4 className="testimonial-customer-name">{item.name}</h4>
                  <div className="testimonial-stars-row">
                    {[...Array(5)].map((_, i) => (
                      <StarIcon key={i} size={14} filled={i < item.rating} />
                    ))}
                  </div>
                </div>
              </div>

              <p className="testimonial-comment-text">"{item.comment}"</p>

              <div className="testimonial-card-footer">
                <span className="verified-pill">✓ {item.role}</span>
                <span className="product-tag-sub">Purchased {item.productPurchased}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Navigation Dots Indicator */}
        <div className="testimonials-dots-indicator">
          {testimonials.map((_, idx) => (
            <button
              key={idx}
              className={`dot-pill ${currentIndex === idx ? 'active' : ''}`}
              onClick={() => setCurrentIndex(idx)}
              aria-label={`View testimonial ${idx + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
