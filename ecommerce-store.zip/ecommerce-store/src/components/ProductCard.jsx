import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import { HeartIcon, StarIcon, CartIcon, CheckIcon } from './Icons';

export const ProductCard = ({ product }) => {
  const { addToCart } = useCart();
  const { toggleWishlist, isInWishlist } = useWishlist();
  const [isAdded, setIsAdded] = useState(false);

  const isLiked = isInWishlist(product.id);
  const mainImage = product.images?.[0] || product.image || 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=600&q=80';
  const defaultSize = product.sizes?.[0] || 'M';
  const defaultColor = product.colors?.[0]?.name || 'Standard';
  const defaultColorHex = product.colors?.[0]?.hex || '#111827';

  const handleAddToCart = (e) => {
    e.preventDefault();
    e.stopPropagation();
    addToCart(product, defaultSize, defaultColor, defaultColorHex, 1);
    setIsAdded(true);
    setTimeout(() => setIsAdded(false), 1600);
  };

  const handleWishlistToggle = (e) => {
    e.preventDefault();
    e.stopPropagation();
    toggleWishlist(product);
  };

  return (
    <div className="product-card">
      {/* Card Image Container */}
      <div className="product-card-image-wrapper">
        <Link to={`/product/${product.id}`} className="product-image-link">
          <img
            src={mainImage}
            alt={product.name}
            className="product-card-image"
            loading="lazy"
          />
        </Link>

        {/* Wishlist Floating Button */}
        <button
          className={`product-wishlist-btn ${isLiked ? 'active' : ''}`}
          onClick={handleWishlistToggle}
          aria-label={isLiked ? 'Remove from wishlist' : 'Add to wishlist'}
        >
          <HeartIcon size={18} filled={isLiked} className={isLiked ? 'text-red' : ''} />
        </button>

        {/* Badges */}
        {product.originalPrice && product.originalPrice > product.price && (
          <span className="product-discount-tag">
            {Math.round(((product.originalPrice - product.price) / product.originalPrice) * 100)}% OFF
          </span>
        )}
      </div>

      {/* Card Details */}
      <div className="product-card-info">
        <div className="product-card-category-brand">
          <span className="product-category-text">{product.category}</span>
          {product.brand && <span className="product-brand-dot">• {product.brand}</span>}
        </div>

        <h3 className="product-card-title">
          <Link to={`/product/${product.id}`}>{product.name}</Link>
        </h3>

        {/* Ratings & Reviews */}
        <div className="product-card-rating">
          <div className="stars-group">
            {[...Array(5)].map((_, i) => (
              <StarIcon
                key={i}
                size={14}
                filled={i < Math.floor(product.rating || 4.5)}
              />
            ))}
          </div>
          <span className="rating-number">{product.rating || 4.5}</span>
          <span className="reviews-count">({product.reviewsCount || 48})</span>
        </div>

        {/* Price & Action */}
        <div className="product-card-footer">
          <div className="product-pricing">
            <span className="current-price">${Number(product.price).toFixed(2)}</span>
            {product.originalPrice && (
              <span className="original-price">${Number(product.originalPrice).toFixed(2)}</span>
            )}
          </div>

          <button
            className={`card-add-btn ${isAdded ? 'added' : ''}`}
            onClick={handleAddToCart}
            aria-label="Add to Cart"
          >
            {isAdded ? (
              <>
                <CheckIcon size={16} />
                <span>Added</span>
              </>
            ) : (
              <>
                <CartIcon size={16} />
                <span>Add</span>
              </>
            )}
          </button>
        </div>
      </div>
    </div>
  );
};
