import React from 'react';
import { Link } from 'react-router-dom';
import { PrinterIcon, CheckIcon, ChevronRightIcon } from './Icons';

export const Receipt = ({ order, onPrint = null }) => {
  if (!order) {
    return (
      <div className="empty-receipt-card">
        <p>No order details found.</p>
        <Link to="/" className="primary-btn">
          Return to Store
        </Link>
      </div>
    );
  }

  const handlePrint = () => {
    if (onPrint) {
      onPrint();
    } else {
      window.print();
    }
  };

  return (
    <div className="printable-receipt-card" id="printable-order-receipt">
      {/* Receipt Header */}
      <div className="receipt-header-row">
        <div className="receipt-brand">
          <div className="brand-logo-text">✦ VELOUR</div>
          <span className="brand-sub">Official Tax Invoice & Order Confirmation</span>
        </div>
        <div className="receipt-actions no-print">
          <button type="button" className="print-receipt-btn" onClick={handlePrint}>
            <PrinterIcon size={18} />
            <span>Print Receipt</span>
          </button>
        </div>
      </div>

      <div className="receipt-divider"></div>

      {/* Meta Grid: Order ID, Date, Customer & Payment */}
      <div className="receipt-meta-grid">
        <div className="meta-block">
          <span className="meta-label">ORDER ID</span>
          <span className="meta-value highlight-id">{order.id}</span>
          <span className="status-badge-pill confirmed">● {order.status || 'Confirmed'}</span>
        </div>

        <div className="meta-block">
          <span className="meta-label">DATE & TIME</span>
          <span className="meta-value">{order.dateString}</span>
        </div>

        <div className="meta-block">
          <span className="meta-label">CUSTOMER DETAILS</span>
          <span className="meta-value font-medium">{order.customer?.fullName}</span>
          <span className="meta-sub">{order.customer?.phone}</span>
          <span className="meta-sub">{order.customer?.email}</span>
        </div>

        <div className="meta-block">
          <span className="meta-label">SHIPPING ADDRESS</span>
          <span className="meta-value">{order.customer?.address}</span>
          {order.customer?.suite && <span className="meta-sub">{order.customer.suite}</span>}
          <span className="meta-sub">
            {order.customer?.city}, {order.customer?.state} {order.customer?.zipCode}
          </span>
        </div>
      </div>

      <div className="receipt-divider"></div>

      {/* Ordered Products Table */}
      <div className="receipt-products-table-wrapper">
        <table className="receipt-products-table">
          <thead>
            <tr>
              <th className="th-item">Product</th>
              <th className="th-attr">Details</th>
              <th className="th-qty">Qty</th>
              <th className="th-price">Price</th>
              <th className="th-total">Total</th>
            </tr>
          </thead>
          <tbody>
            {order.items?.map((item, idx) => (
              <tr key={idx} className="receipt-item-row">
                <td className="td-item">
                  <div className="receipt-item-cell">
                    {item.image && (
                      <img
                        src={item.image}
                        alt={item.name}
                        className="receipt-thumb-img"
                      />
                    )}
                    <span className="receipt-item-name">{item.name}</span>
                  </div>
                </td>
                <td className="td-attr">
                  <span className="receipt-meta-pill">
                    {item.size ? `Size: ${item.size}` : ''}
                    {item.color ? ` • ${item.color}` : ''}
                  </span>
                </td>
                <td className="td-qty">{item.quantity}</td>
                <td className="td-price">${Number(item.price).toFixed(2)}</td>
                <td className="td-total">
                  ${(Number(item.price) * item.quantity).toFixed(2)}
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Pricing Summary */}
      <div className="receipt-summary-container">
        <div className="payment-info-box">
          <span className="meta-label">PAYMENT METHOD</span>
          <span className="meta-value font-medium">{order.payment?.method}</span>
          <span className="meta-sub">{order.payment?.details}</span>
          <span className="payment-paid-badge">✓ Paid in Full</span>
        </div>

        <div className="receipt-totals-table">
          <div className="total-line">
            <span>Subtotal</span>
            <span>${Number(order.pricing?.subtotal || 0).toFixed(2)}</span>
          </div>
          {order.pricing?.discount > 0 && (
            <div className="total-line discount-line">
              <span>Coupon Discount</span>
              <span>-${Number(order.pricing.discount).toFixed(2)}</span>
            </div>
          )}
          <div className="total-line">
            <span>Shipping</span>
            <span>
              {Number(order.pricing?.shipping || 0) === 0
                ? 'FREE'
                : `$${Number(order.pricing.shipping).toFixed(2)}`}
            </span>
          </div>
          <div className="total-line">
            <span>Estimated Tax (6%)</span>
            <span>${Number(order.pricing?.tax || 0).toFixed(2)}</span>
          </div>
          <div className="receipt-divider my-2"></div>
          <div className="total-line grand-total-line">
            <span>Total Paid</span>
            <span className="grand-total-amount">
              ${Number(order.pricing?.total || 0).toFixed(2)}
            </span>
          </div>
        </div>
      </div>

      {/* Footer message */}
      <div className="receipt-footer-note">
        <p>Thank you for shopping with VELOUR! A copy of this receipt has been emailed to {order.customer?.email}.</p>
        <p className="warranty-text">All purchases include a 30-day return policy and full manufacturer warranty.</p>
      </div>
    </div>
  );
};
