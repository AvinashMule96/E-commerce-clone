import React from 'react';
import { Link } from 'react-router-dom';
import { categories } from '../data/categories';
import { ChevronRightIcon } from './Icons';

export const CategoryCards = () => {
  const topCategories = categories.slice(0, 5);

  return (
    <section className="top-categories-section">
      <div className="section-header-row">
        <h2 className="section-title-heading">Top Categories</h2>
        <Link to="/category" className="view-all-link">
          <span>View All</span>
          <ChevronRightIcon size={16} />
        </Link>
      </div>

      <div className="categories-cards-grid">
        {topCategories.map((cat) => (
          <Link
            key={cat.id}
            to={`/category?cat=${cat.slug}`}
            className="category-card-item"
          >
            <div className="category-image-container">
              <img
                src={cat.image}
                alt={cat.name}
                className="category-image"
                loading="lazy"
              />
              <div className="category-card-overlay"></div>
            </div>
            <div className="category-card-caption">
              <h3 className="category-title">{cat.name}</h3>
              <span className="category-count-badge">{cat.count}+ items</span>
            </div>
          </Link>
        ))}
      </div>
    </section>
  );
};
