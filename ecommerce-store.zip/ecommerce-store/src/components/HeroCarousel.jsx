import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import { ChevronLeftIcon, ChevronRightIcon } from './Icons';

const HERO_SLIDES = [
  {
    id: 1,
    tagline: 'New Arrivals',
    title: 'Summer Collection',
    subtitle: 'Discover breathable fabrics, modern silhouettes, and effortless everyday essentials.',
    buttonText: 'SHOP NOW',
    link: '/category?cat=men',
    bgGradient: 'linear-gradient(135deg, #f1f5f9 0%, #e2e8f0 100%)',
    image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=1000&q=80',
    accentColor: '#111827'
  },
  {
    id: 2,
    tagline: 'Performance Footwear',
    title: 'Urban Runner Edition',
    subtitle: 'Ultra-cushioned responsive sneakers built for speed, stability, and street style.',
    buttonText: 'EXPLORE FOOTWEAR',
    link: '/category?cat=footwear',
    bgGradient: 'linear-gradient(135deg, #f8fafc 0%, #e2e8f0 100%)',
    image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=1000&q=80',
    accentColor: '#111827'
  },
  {
    id: 3,
    tagline: 'Limited Time Offer',
    title: 'Up To 50% Off Deals',
    subtitle: 'Shop our curated seasonal selection with complimentary express shipping on all orders.',
    buttonText: 'CLAIM DEALS',
    link: '/category?cat=deals',
    bgGradient: 'linear-gradient(135deg, #f3f4f6 0%, #e5e7eb 100%)',
    image: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=1000&q=80',
    accentColor: '#111827'
  }
];

export const HeroCarousel = () => {
  const [currentSlide, setCurrentSlide] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
    }, 5000);
    return () => clearInterval(timer);
  }, []);

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev + 1) % HERO_SLIDES.length);
  };

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev - 1 + HERO_SLIDES.length) % HERO_SLIDES.length);
  };

  const slide = HERO_SLIDES[currentSlide];

  return (
    <section className="hero-carousel-section">
      <div className="hero-slide-container" style={{ background: slide.bgGradient }}>
        {/* Left Text Content */}
        <div className="hero-content">
          <span className="hero-tagline-pill">{slide.tagline}</span>
          <h1 className="hero-main-title">{slide.title}</h1>
          <p className="hero-subtitle-text">{slide.subtitle}</p>
          <div className="hero-actions">
            <Link to={slide.link} className="hero-cta-btn">
              {slide.buttonText}
            </Link>
          </div>
        </div>

        {/* Right Hero Image / Illustration */}
        <div className="hero-visual">
          <div className="hero-image-frame">
            <img
              src={slide.image}
              alt={slide.title}
              className="hero-featured-image"
            />
          </div>
        </div>

        {/* Carousel Arrow Controls */}
        <button
          className="hero-arrow-btn left-arrow"
          onClick={prevSlide}
          aria-label="Previous Slide"
        >
          <ChevronLeftIcon size={20} />
        </button>
        <button
          className="hero-arrow-btn right-arrow"
          onClick={nextSlide}
          aria-label="Next Slide"
        >
          <ChevronRightIcon size={20} />
        </button>

        {/* Carousel Dots Indicators */}
        <div className="hero-dots-indicator">
          {HERO_SLIDES.map((_, index) => (
            <button
              key={index}
              className={`hero-dot ${currentSlide === index ? 'active' : ''}`}
              onClick={() => setCurrentSlide(index)}
              aria-label={`Go to slide ${index + 1}`}
            />
          ))}
        </div>
      </div>
    </section>
  );
};
