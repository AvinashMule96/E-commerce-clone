import React, { useState, useRef, useEffect } from 'react';
import { initialChatMessages } from '../data/testimonials';
import { ChatIcon, CloseIcon, SendIcon, CheckIcon } from './Icons';

export const LiveChatWidget = () => {
  const [isOpen, setIsOpen] = useState(false);
  const [activeTab, setActiveTab] = useState('chat'); // 'chat' | 'form'
  const [messages, setMessages] = useState(initialChatMessages);
  const [inputMessage, setInputMessage] = useState('');
  const [isTyping, setIsTyping] = useState(false);

  // Send message contact form state
  const [formData, setFormData] = useState({ name: '', email: '', message: '' });
  const [formSubmitted, setFormSubmitted] = useState(false);

  const chatEndRef = useRef(null);

  useEffect(() => {
    if (isOpen && activeTab === 'chat') {
      chatEndRef.current?.scrollIntoView({ behavior: 'smooth' });
    }
  }, [messages, isOpen, activeTab]);

  const handleSendMessage = (e) => {
    e.preventDefault();
    if (!inputMessage.trim()) return;

    const now = new Date();
    const timeString = now.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });

    const userMsg = {
      id: `msg-${Date.now()}`,
      sender: 'user',
      text: inputMessage.trim(),
      time: timeString
    };

    setMessages((prev) => [...prev, userMsg]);
    setInputMessage('');
    setIsTyping(true);

    // Simulate smart bot response
    setTimeout(() => {
      let botResponse = "Thank you for reaching out! Our support team has logged your inquiry and will update your order dashboard within 15 minutes.";
      const lower = userMsg.text.toLowerCase();
      if (lower.includes('return') || lower.includes('refund')) {
        botResponse = "We offer a 30-day hassle-free return policy! You can initiate a return directly from the My Orders page.";
      } else if (lower.includes('shipping') || lower.includes('delivery')) {
        botResponse = "Standard delivery takes 2-4 business days. Express shipping delivers within 24-48 hours with full live tracking!";
      } else if (lower.includes('ord-') || lower.includes('order')) {
        botResponse = "I've located your order details! Your shipment is currently packed and will be dispatched today with express tracking.";
      }

      setMessages((prev) => [
        ...prev,
        {
          id: `msg-${Date.now() + 1}`,
          sender: 'agent',
          text: botResponse,
          time: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
        }
      ]);
      setIsTyping(false);
    }, 1200);
  };

  const handleFormSubmit = (e) => {
    e.preventDefault();
    if (!formData.name || !formData.email || !formData.message) return;

    setFormSubmitted(true);
    setTimeout(() => {
      setFormSubmitted(false);
      setFormData({ name: '', email: '', message: '' });
      setActiveTab('chat');
    }, 2500);
  };

  return (
    <div className="live-chat-floating-container">
      {/* Floating Action Button */}
      {!isOpen && (
        <button
          className="live-chat-toggle-btn"
          onClick={() => setIsOpen(true)}
          aria-label="Open Live Chat"
          title="Chat with Customer Support"
        >
          <ChatIcon size={24} />
          <span className="live-chat-indicator"></span>
        </button>
      )}

      {/* Floating Chat Modal */}
      {isOpen && (
        <div className="live-chat-card">
          {/* Header */}
          <div className="chat-card-header">
            <div className="chat-header-info">
              <span className="online-dot"></span>
              <h3 className="chat-header-title">
                {activeTab === 'chat' ? 'Chat with us' : 'Send Message'}
              </h3>
            </div>

            <div className="chat-header-controls">
              <button
                className={`chat-tab-switch ${activeTab === 'chat' ? 'active' : ''}`}
                onClick={() => setActiveTab('chat')}
              >
                Live Chat
              </button>
              <button
                className={`chat-tab-switch ${activeTab === 'form' ? 'active' : ''}`}
                onClick={() => setActiveTab('form')}
              >
                Contact
              </button>
              <button
                className="chat-close-btn"
                onClick={() => setIsOpen(false)}
                aria-label="Close Chat"
              >
                <CloseIcon size={18} />
              </button>
            </div>
          </div>

          {/* Body: Live Chat Conversation */}
          {activeTab === 'chat' && (
            <div className="chat-conversation-body">
              <div className="chat-messages-container">
                {messages.map((msg) => (
                  <div
                    key={msg.id}
                    className={`chat-bubble-wrapper ${msg.sender === 'user' ? 'user-side' : 'agent-side'}`}
                  >
                    <div className="chat-bubble">
                      <p className="bubble-text">{msg.text}</p>
                      <span className="bubble-timestamp">{msg.time}</span>
                    </div>
                  </div>
                ))}

                {isTyping && (
                  <div className="chat-bubble-wrapper agent-side">
                    <div className="chat-bubble typing-bubble">
                      <span className="dot"></span>
                      <span className="dot"></span>
                      <span className="dot"></span>
                    </div>
                  </div>
                )}
                <div ref={chatEndRef} />
              </div>

              {/* Chat Input Bar */}
              <form className="chat-input-row" onSubmit={handleSendMessage}>
                <input
                  type="text"
                  placeholder="Type your message..."
                  value={inputMessage}
                  onChange={(e) => setInputMessage(e.target.value)}
                  className="chat-input-field"
                />
                <button
                  type="submit"
                  className="chat-send-btn"
                  disabled={!inputMessage.trim()}
                  aria-label="Send message"
                >
                  <SendIcon size={16} />
                </button>
              </form>
            </div>
          )}

          {/* Body: Send Message Form */}
          {activeTab === 'form' && (
            <div className="chat-form-body">
              {formSubmitted ? (
                <div className="form-success-message">
                  <div className="success-icon-badge">
                    <CheckIcon size={24} />
                  </div>
                  <h4>Message Sent!</h4>
                  <p>Our customer experience team will reply to {formData.email} within 2 hours.</p>
                </div>
              ) : (
                <form className="contact-support-form" onSubmit={handleFormSubmit}>
                  <div className="form-group-field">
                    <label>Name</label>
                    <input
                      type="text"
                      placeholder="Enter your name"
                      value={formData.name}
                      onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                      required
                    />
                  </div>

                  <div className="form-group-field">
                    <label>Email</label>
                    <input
                      type="email"
                      placeholder="Enter your email"
                      value={formData.email}
                      onChange={(e) => setFormData({ ...formData, email: e.target.value })}
                      required
                    />
                  </div>

                  <div className="form-group-field">
                    <label>Message</label>
                    <textarea
                      rows={3}
                      placeholder="Type your message here..."
                      value={formData.message}
                      onChange={(e) => setFormData({ ...formData, message: e.target.value })}
                      required
                    ></textarea>
                  </div>

                  <button type="submit" className="primary-btn full-width">
                    SEND MESSAGE
                  </button>
                </form>
              )}
            </div>
          )}
        </div>
      )}
    </div>
  );
};
