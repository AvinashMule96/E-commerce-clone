import React from 'react';
import { categories } from '../data/categories';

export const FilterSidebar = ({
  selectedCategory,
  onSelectCategory,
  priceRange,
  onPriceChange,
  selectedBrands,
  onToggleBrand,
  selectedSizes,
  onToggleSize,
  selectedColors,
  onToggleColor,
  onResetFilters
}) => {
  const brands = ["Levi's", 'Nike', 'Adidas', 'Puma', 'U.S. Polo', 'Zara', 'Fossil', 'H&M'];
  const sizes = ['S', 'M', 'L', 'XL', 'XXL'];
  const colors = [
    { name: 'Olive Green', hex: '#556b2f' },
    { name: 'Navy Blue', hex: '#1e3a8a' },
    { name: 'Black', hex: '#111827' },
    { name: 'White', hex: '#f3f4f6' },
    { name: 'Beige', hex: '#d4b996' },
    { name: 'Gray', hex: '#6b7280' }
  ];

  return (
    <aside className="filter-sidebar">
      {/* Category Selection */}
      <div className="filter-group">
        <h3 className="filter-section-title">CATEGORIES</h3>
        <ul className="category-filter-list">
          <li
            className={`cat-filter-item ${!selectedCategory || selectedCategory === 'all' ? 'active' : ''}`}
            onClick={() => onSelectCategory('all')}
          >
            <span>All Categories</span>
          </li>
          {categories.map((cat) => (
            <li
              key={cat.id}
              className={`cat-filter-item ${selectedCategory === cat.slug ? 'active' : ''}`}
              onClick={() => onSelectCategory(cat.slug)}
            >
              <span>{cat.name}</span>
              <span className="cat-count-sub">({cat.count})</span>
            </li>
          ))}
        </ul>
      </div>

      <div className="filter-divider"></div>

      <div className="filter-group">
        <div className="filter-group-header">
          <h3 className="filter-section-title">FILTERS</h3>
          <button
            type="button"
            className="filter-reset-link"
            onClick={onResetFilters}
          >
            Clear All
          </button>
        </div>

        {/* Price Slider */}
        <div className="filter-sub-group">
          <div className="price-label-row">
            <span className="filter-sub-title">Price</span>
            <span className="price-range-val">$0 - ${priceRange}</span>
          </div>
          <input
            type="range"
            min="10"
            max="200"
            step="5"
            value={priceRange}
            onChange={(e) => onPriceChange(Number(e.target.value))}
            className="price-slider-input"
          />
          <div className="price-scale-labels">
            <span>$0</span>
            <span>$200</span>
          </div>
        </div>

        {/* Brand Checkboxes */}
        <div className="filter-sub-group">
          <h4 className="filter-sub-title">Brand</h4>
          <div className="checkbox-list">
            {brands.map((brand) => (
              <label key={brand} className="custom-checkbox-label">
                <input
                  type="checkbox"
                  checked={selectedBrands.includes(brand)}
                  onChange={() => onToggleBrand(brand)}
                />
                <span className="checkbox-custom"></span>
                <span className="brand-name-text">{brand}</span>
              </label>
            ))}
          </div>
        </div>

        {/* Size Selection */}
        <div className="filter-sub-group">
          <h4 className="filter-sub-title">Size</h4>
          <div className="size-chips-grid">
            {sizes.map((size) => (
              <button
                key={size}
                type="button"
                className={`size-chip-btn ${selectedSizes.includes(size) ? 'active' : ''}`}
                onClick={() => onToggleSize(size)}
              >
                {size}
              </button>
            ))}
          </div>
        </div>

        {/* Color Swatches */}
        <div className="filter-sub-group">
          <h4 className="filter-sub-title">Color</h4>
          <div className="color-swatches-grid">
            {colors.map((col) => (
              <button
                key={col.name}
                type="button"
                className={`color-swatch-circle ${selectedColors.includes(col.name) ? 'active' : ''}`}
                style={{ backgroundColor: col.hex }}
                onClick={() => onToggleColor(col.name)}
                title={col.name}
              />
            ))}
          </div>
        </div>
      </div>
    </aside>
  );
};
