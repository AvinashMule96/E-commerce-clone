import React, { useState, useRef, useEffect } from 'react';
import { Link, useNavigate, useLocation } from 'react-router-dom';
import { useAuth } from '../context/AuthContext';
import { useCart } from '../context/CartContext';
import { useWishlist } from '../context/WishlistContext';
import {
  SearchIcon,
  CartIcon,
  HeartIcon,
  UserIcon,
  MenuIcon,
  CloseIcon,
  ChevronDownIcon
} from './Icons';

export const Navbar = () => {
  const { user, isAuthenticated, logout } = useAuth();
  const { totalItemCount } = useCart();
  const { wishlistCount } = useWishlist();
  const navigate = useNavigate();
  const location = useLocation();

  const [searchQuery, setSearchQuery] = useState('');
  const [isUserMenuOpen, setIsUserMenuOpen] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const userMenuRef = useRef(null);

  useEffect(() => {
    const handleClickOutside = (e) => {
      if (userMenuRef.current && !userMenuRef.current.contains(e.target)) {
        setIsUserMenuOpen(false);
      }
    };
    document.addEventListener('mousedown', handleClickOutside);
    return () => document.removeEventListener('mousedown', handleClickOutside);
  }, []);

  // Close menus on route change
  useEffect(() => {
    setIsMobileMenuOpen(false);
    setIsUserMenuOpen(false);
  }, [location.pathname]);

  const handleSearchSubmit = (e) => {
    e.preventDefault();
    if (searchQuery.trim()) {
      navigate(`/category?search=${encodeURIComponent(searchQuery.trim())}`);
    } else {
      navigate('/category');
    }
  };

  return (
    <>
      <header className="navbar-header">
        <div className="navbar-container">
          {/* Left: Mobile Menu Toggle & Brand Logo */}
          <div className="navbar-left">
            <button
              className="navbar-icon-btn mobile-menu-btn"
              onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              aria-label="Toggle Navigation Menu"
            >
              <MenuIcon size={24} />
            </button>

            <Link to="/" className="navbar-logo">
              <span className="logo-badge">✦</span>
              <span className="logo-text">VELOUR</span>
            </Link>

            {/* Desktop Navigation Links */}
            <nav className="desktop-nav-links">
              <Link to="/" className={`nav-link ${location.pathname === '/' ? 'active' : ''}`}>
                Home
              </Link>
              <Link to="/category" className={`nav-link ${location.pathname.startsWith('/category') ? 'active' : ''}`}>
                Shop
              </Link>
              <Link to="/category?cat=men" className="nav-link">
                Men
              </Link>
              <Link to="/category?cat=women" className="nav-link">
                Women
              </Link>
              <Link to="/category?cat=deals" className="nav-link deals-badge-link">
                Deals <span className="hot-pill">HOT</span>
              </Link>
            </nav>
          </div>

          {/* Center: Search Bar */}
          <div className="navbar-center">
            <form className="navbar-search-form" onSubmit={handleSearchSubmit}>
              <SearchIcon size={18} className="search-input-icon" />
              <input
                type="text"
                placeholder="Search products, brands, categories..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="navbar-search-input"
              />
              {searchQuery && (
                <button
                  type="button"
                  className="search-clear-btn"
                  onClick={() => setSearchQuery('')}
                >
                  <CloseIcon size={14} />
                </button>
              )}
              <button type="submit" className="search-action-btn">
                Search
              </button>
            </form>
          </div>

          {/* Right: Wishlist, Cart, Profile */}
          <div className="navbar-right">
            {/* Wishlist Button */}
            <Link to="/wishlist" className="navbar-icon-btn" aria-label="View Wishlist" title="Wishlist">
              <HeartIcon size={22} filled={wishlistCount > 0} className={wishlistCount > 0 ? 'text-red' : ''} />
              {wishlistCount > 0 && <span className="icon-badge">{wishlistCount}</span>}
            </Link>

            {/* Cart Button */}
            <Link to="/cart" className="navbar-icon-btn cart-btn" aria-label="View Shopping Cart" title="Shopping Cart">
              <CartIcon size={22} />
              {totalItemCount > 0 && <span className="icon-badge">{totalItemCount}</span>}
            </Link>

            {/* User Dropdown */}
            <div className="user-menu-container" ref={userMenuRef}>
              {isAuthenticated && user ? (
                <button
                  className="user-profile-toggle"
                  onClick={() => setIsUserMenuOpen(!isUserMenuOpen)}
                  aria-label="User Account Menu"
                >
                  <div className="avatar-circle">
                    <UserIcon size={18} />
                  </div>
                  <span className="user-name-label">{user.name.split(' ')[0]}</span>
                  <ChevronDownIcon size={16} />
                </button>
              ) : (
                <Link to="/login" className="login-link-btn">
                  <UserIcon size={18} />
                  <span>Login</span>
                </Link>
              )}

              {/* User Dropdown Menu matching Figma Wireframe */}
              {isUserMenuOpen && isAuthenticated && (
                <div className="user-dropdown-card">
                  <div className="user-card-header">
                    <div className="user-avatar-large">
                      <UserIcon size={24} />
                    </div>
                    <div className="user-meta-info">
                      <div className="user-full-name">{user?.name || 'User Name'}</div>
                      <div className="user-email-text">{user?.email || 'user@email.com'}</div>
                    </div>
                  </div>

                  <div className="dropdown-divider"></div>

                  <ul className="dropdown-menu-list">
                    <li>
                      <Link to="/orders" className="dropdown-item" onClick={() => setIsUserMenuOpen(false)}>
                        <span className="menu-bullet">📦</span> My Orders
                      </Link>
                    </li>
                    <li>
                      <Link to="/wishlist" className="dropdown-item" onClick={() => setIsUserMenuOpen(false)}>
                        <span className="menu-bullet">❤️</span> Wishlist
                      </Link>
                    </li>
                    <li>
                      <Link to="/checkout" className="dropdown-item" onClick={() => setIsUserMenuOpen(false)}>
                        <span className="menu-bullet">📍</span> Saved Addresses
                      </Link>
                    </li>
                    <li>
                      <button
                        className="dropdown-item"
                        onClick={() => {
                          setIsUserMenuOpen(false);
                          alert('Account Settings: Profile is in active test mode.');
                        }}
                      >
                        <span className="menu-bullet">⚙️</span> Account Settings
                      </button>
                    </li>
                  </ul>

                  <div className="dropdown-divider"></div>

                  <button
                    className="dropdown-item logout-item"
                    onClick={() => {
                      logout();
                      setIsUserMenuOpen(false);
                      navigate('/');
                    }}
                  >
                    <span className="menu-bullet">🚪</span> Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </div>

        {/* Mobile Navigation Drawer */}
        {isMobileMenuOpen && (
          <div className="mobile-drawer-overlay" onClick={() => setIsMobileMenuOpen(false)}>
            <div className="mobile-drawer" onClick={(e) => e.stopPropagation()}>
              <div className="drawer-header">
                <div className="navbar-logo">
                  <span className="logo-badge">✦</span>
                  <span className="logo-text">VELOUR</span>
                </div>
                <button
                  className="navbar-icon-btn"
                  onClick={() => setIsMobileMenuOpen(false)}
                  aria-label="Close menu"
                >
                  <CloseIcon size={20} />
                </button>
              </div>

              <div className="mobile-search-wrapper">
                <form className="navbar-search-form" onSubmit={handleSearchSubmit}>
                  <SearchIcon size={18} className="search-input-icon" />
                  <input
                    type="text"
                    placeholder="Search products..."
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="navbar-search-input"
                  />
                  <button type="submit" className="search-action-btn">
                    Go
                  </button>
                </form>
              </div>

              <nav className="mobile-nav-links">
                <Link to="/" className="mobile-nav-item">
                  🏠 Home
                </Link>
                <Link to="/category" className="mobile-nav-item">
                  🛍️ All Products
                </Link>
                <Link to="/category?cat=men" className="mobile-nav-item">
                  👔 Men's Fashion
                </Link>
                <Link to="/category?cat=women" className="mobile-nav-item">
                  👗 Women's Fashion
                </Link>
                <Link to="/category?cat=footwear" className="mobile-nav-item">
                  👟 Footwear
                </Link>
                <Link to="/category?cat=bags" className="mobile-nav-item">
                  👜 Bags & Luggage
                </Link>
                <Link to="/category?cat=watches" className="mobile-nav-item">
                  ⌚ Watches
                </Link>
                <Link to="/category?cat=deals" className="mobile-nav-item deals-mobile-item">
                  🔥 Seasonal Deals
                </Link>
              </nav>

              <div className="drawer-footer">
                {isAuthenticated ? (
                  <div className="drawer-user-actions">
                    <div className="drawer-user-info">
                      <strong>{user?.name}</strong>
                      <span>{user?.email}</span>
                    </div>
                    <div className="drawer-btn-grid">
                      <Link to="/orders" className="drawer-action-link">
                        My Orders
                      </Link>
                      <button onClick={logout} className="drawer-action-link text-red">
                        Logout
                      </button>
                    </div>
                  </div>
                ) : (
                  <Link to="/login" className="primary-btn full-width">
                    Login / Sign Up
                  </Link>
                )}
              </div>
            </div>
          </div>
        )}
      </header>
    </>
  );
};
