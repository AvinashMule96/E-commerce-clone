import React, { useState } from 'react';
import { bookingTimeSlots } from '../data/testimonials';
import { CalendarIcon, ClockIcon, CheckIcon, ChevronLeftIcon, ChevronRightIcon } from './Icons';

export const BookingWidget = () => {
  const [selectedDay, setSelectedDay] = useState(12);
  const [selectedSlot, setSelectedSlot] = useState('10:00 AM');
  const [currentMonth, setCurrentMonth] = useState('June 2024');
  const [bookingSuccess, setBookingSuccess] = useState(false);
  const [bookedDetails, setBookedDetails] = useState(null);

  // Calendar dates for June 2024 (matching Figma wireframe)
  // June 2024 started on Saturday (day index 6) with 30 days
  const daysInMonth = Array.from({ length: 30 }, (_, i) => i + 1);
  const startDayOffset = 6; // Saturday offset

  const handleConfirmBooking = (e) => {
    e.preventDefault();
    const details = {
      date: `${currentMonth.split(' ')[0]} ${selectedDay}, ${currentMonth.split(' ')[1]}`,
      time: selectedSlot,
      service: 'VIP Personal Styling & Size Consultation',
      id: `BK-${Math.floor(1000 + Math.random() * 9000)}`
    };
    setBookedDetails(details);
    setBookingSuccess(true);
  };

  return (
    <section className="booking-widget-section">
      <div className="section-header-center">
        <span className="section-sub-tag">BOOK / CALENDAR</span>
        <h2 className="section-title-heading">Book a VIP Styling Consultation</h2>
        <p className="section-sub-desc">Schedule a 1-on-1 virtual fit and styling session with our certified fashion specialists.</p>
      </div>

      <div className="booking-card-wrapper">
        <div className="booking-card-box">
          <div className="booking-card-header">
            <h3 className="booking-card-title">Select Date & Time</h3>
          </div>

          {/* Month Header Navigation */}
          <div className="calendar-month-row">
            <button className="calendar-nav-btn" aria-label="Previous Month">
              <ChevronLeftIcon size={16} />
            </button>
            <span className="calendar-month-name">{currentMonth}</span>
            <button className="calendar-nav-btn" aria-label="Next Month">
              <ChevronRightIcon size={16} />
            </button>
          </div>

          {/* Days of Week Header */}
          <div className="calendar-weekdays-grid">
            <span>Sun</span>
            <span>Mon</span>
            <span>Tue</span>
            <span>Wed</span>
            <span>Thu</span>
            <span>Fri</span>
            <span>Sat</span>
          </div>

          {/* Calendar Days Matrix */}
          <div className="calendar-days-grid">
            {/* Empty slots for starting offset */}
            {Array.from({ length: startDayOffset }).map((_, idx) => (
              <span key={`empty-${idx}`} className="calendar-day empty"></span>
            ))}
            {daysInMonth.map((day) => (
              <button
                key={day}
                type="button"
                className={`calendar-day ${selectedDay === day ? 'selected' : ''}`}
                onClick={() => setSelectedDay(day)}
              >
                {day}
              </button>
            ))}
          </div>

          {/* Available Time Slots Section */}
          <div className="time-slots-wrapper">
            <h4 className="time-slots-heading">
              <ClockIcon size={16} />
              <span>Available Time Slots</span>
            </h4>

            <div className="time-slots-grid">
              {bookingTimeSlots.map((slot) => (
                <button
                  key={slot.id}
                  type="button"
                  className={`time-slot-btn ${selectedSlot === slot.time ? 'active' : ''}`}
                  onClick={() => setSelectedSlot(slot.time)}
                >
                  {slot.time}
                </button>
              ))}
            </div>
          </div>

          {/* Confirm Booking Action Button */}
          <button
            type="button"
            className="booking-confirm-btn"
            onClick={handleConfirmBooking}
          >
            CONFIRM BOOKING
          </button>
        </div>
      </div>

      {/* Booking Confirmation Modal */}
      {bookingSuccess && bookedDetails && (
        <div className="modal-overlay" onClick={() => setBookingSuccess(false)}>
          <div className="modal-content-card" onClick={(e) => e.stopPropagation()}>
            <div className="modal-success-icon">
              <CheckIcon size={28} />
            </div>
            <h3 className="modal-title">Consultation Confirmed!</h3>
            <p className="modal-subtitle">Your appointment booking #{bookedDetails.id} has been registered.</p>

            <div className="modal-details-box">
              <div className="detail-row">
                <span className="detail-label">Service:</span>
                <span className="detail-val">{bookedDetails.service}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Date:</span>
                <span className="detail-val">{bookedDetails.date}</span>
              </div>
              <div className="detail-row">
                <span className="detail-label">Time Slot:</span>
                <span className="detail-val">{bookedDetails.time}</span>
              </div>
            </div>

            <button
              className="primary-btn full-width"
              onClick={() => setBookingSuccess(false)}
            >
              Done
            </button>
          </div>
        </div>
      )}
    </section>
  );
};
