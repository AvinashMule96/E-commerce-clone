import React from 'react';
import { Link } from 'react-router-dom';
import { useCart } from '../context/CartContext';
import { MinusIcon, PlusIcon, TrashIcon } from './Icons';

export const CartItem = ({ item }) => {
  const { updateQuantity, removeFromCart } = useCart();

  return (
    <div className="cart-item-row">
      {/* Product Image */}
      <div className="cart-item-image-col">
        <Link to={`/product/${item.productId}`}>
          <img src={item.image} alt={item.name} className="cart-item-thumbnail" />
        </Link>
      </div>

      {/* Product Details */}
      <div className="cart-item-info-col">
        <h4 className="cart-item-title">
          <Link to={`/product/${item.productId}`}>{item.name}</Link>
        </h4>

        <div className="cart-item-attributes">
          {item.size && (
            <span className="attr-pill">
              <strong>Size:</strong> {item.size}
            </span>
          )}
          {item.color && (
            <span className="attr-pill">
              <strong>Color:</strong> {item.color}
              {item.colorHex && (
                <span
                  className="color-dot"
                  style={{ backgroundColor: item.colorHex }}
                />
              )}
            </span>
          )}
        </div>

        <div className="cart-item-price-unit">
          ${Number(item.price).toFixed(2)} each
        </div>
      </div>

      {/* Quantity Stepper */}
      <div className="cart-item-qty-col">
        <div className="quantity-stepper">
          <button
            type="button"
            className="qty-btn"
            onClick={() => updateQuantity(item.id, item.quantity - 1)}
            aria-label="Decrease quantity"
          >
            <MinusIcon size={14} />
          </button>
          <span className="qty-value">{item.quantity}</span>
          <button
            type="button"
            className="qty-btn"
            onClick={() => updateQuantity(item.id, item.quantity + 1)}
            aria-label="Increase quantity"
          >
            <PlusIcon size={14} />
          </button>
        </div>
      </div>

      {/* Subtotal & Delete */}
      <div className="cart-item-total-col">
        <div className="cart-item-total-price">
          ${(Number(item.price) * item.quantity).toFixed(2)}
        </div>
        <button
          type="button"
          className="cart-item-remove-btn"
          onClick={() => removeFromCart(item.id)}
          aria-label="Remove item"
          title="Remove item"
        >
          <TrashIcon size={16} />
        </button>
      </div>
    </div>
  );
};
