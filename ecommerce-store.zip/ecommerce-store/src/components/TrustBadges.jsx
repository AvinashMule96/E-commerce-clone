import React from 'react';
import { TruckIcon, ReturnIcon, ShieldIcon, SupportIcon } from './Icons';

export const TrustBadges = () => {
  const features = [
    {
      icon: <TruckIcon size={24} />,
      title: 'Free Shipping',
      description: 'On all orders above $50.00'
    },
    {
      icon: <ReturnIcon size={24} />,
      title: 'Easy Returns',
      description: '30-day hassle-free return policy'
    },
    {
      icon: <ShieldIcon size={24} />,
      title: 'Secure Payment',
      description: '100% encrypted & protected'
    },
    {
      icon: <SupportIcon size={24} />,
      title: '24/7 Support',
      description: 'Dedicated customer assistance'
    }
  ];

  return (
    <section className="trust-badges-section">
      <div className="trust-badges-grid">
        {features.map((feat, idx) => (
          <div key={idx} className="trust-badge-item">
            <div className="trust-icon-box">{feat.icon}</div>
            <div className="trust-text-box">
              <h4 className="trust-title">{feat.title}</h4>
              <p className="trust-desc">{feat.description}</p>
            </div>
          </div>
        ))}
      </div>
    </section>
  );
};
