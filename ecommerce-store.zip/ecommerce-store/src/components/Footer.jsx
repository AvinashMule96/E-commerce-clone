import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { CheckIcon } from './Icons';

export const Footer = () => {
  const [email, setEmail] = useState('');
  const [subscribed, setSubscribed] = useState(false);

  const handleNewsletter = (e) => {
    e.preventDefault();
    if (email.trim()) {
      setSubscribed(true);
      setTimeout(() => {
        setSubscribed(false);
        setEmail('');
      }, 3000);
    }
  };

  return (
    <footer className="site-footer">
      <div className="footer-top-container">
        {/* Brand Col */}
        <div className="footer-col brand-col">
          <div className="footer-logo">
            <span className="logo-badge">✦</span>
            <span className="logo-text">VELOUR</span>
          </div>
          <p className="footer-tagline">
            Curated premium lifestyle, contemporary apparel, footwear, and timeless accessories designed for everyday elegance.
          </p>
          <div className="footer-social-links">
            <a href="#instagram" className="social-icon-link" aria-label="Instagram">Instagram</a>
            <a href="#twitter" className="social-icon-link" aria-label="Twitter">Twitter</a>
            <a href="#pinterest" className="social-icon-link" aria-label="Pinterest">Pinterest</a>
          </div>
        </div>

        {/* Shop Col */}
        <div className="footer-col">
          <h4 className="footer-heading">Shop</h4>
          <ul className="footer-links-list">
            <li><Link to="/category?cat=men">Men's Apparel</Link></li>
            <li><Link to="/category?cat=women">Women's Fashion</Link></li>
            <li><Link to="/category?cat=footwear">Footwear</Link></li>
            <li><Link to="/category?cat=bags">Bags & Backpacks</Link></li>
            <li><Link to="/category?cat=watches">Watches</Link></li>
            <li><Link to="/category?cat=deals">Sale & Deals</Link></li>
          </ul>
        </div>

        {/* Customer Care Col */}
        <div className="footer-col">
          <h4 className="footer-heading">Customer Care</h4>
          <ul className="footer-links-list">
            <li><Link to="/orders">Order Tracking</Link></li>
            <li><Link to="/checkout">Shipping Policy</Link></li>
            <li><Link to="/category">Returns & Exchanges</Link></li>
            <li><Link to="/wishlist">My Wishlist</Link></li>
            <li><Link to="/login">Account Settings</Link></li>
          </ul>
        </div>

        {/* Newsletter Col */}
        <div className="footer-col newsletter-col">
          <h4 className="footer-heading">Stay Connected</h4>
          <p className="newsletter-text">
            Subscribe to receive exclusive seasonal previews, private member discounts, and styling tips.
          </p>
          {subscribed ? (
            <div className="subscribed-badge">
              <CheckIcon size={16} />
              <span>Thank you for subscribing!</span>
            </div>
          ) : (
            <form className="newsletter-form" onSubmit={handleNewsletter}>
              <input
                type="email"
                placeholder="Enter your email"
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                required
                className="newsletter-input"
              />
              <button type="submit" className="newsletter-submit-btn">
                Join
              </button>
            </form>
          )}
        </div>
      </div>

      <div className="footer-bottom-bar">
        <div className="footer-bottom-container">
          <p className="copyright-text">
            © {new Date().getFullYear()} VELOUR Store Inc. All rights reserved.
          </p>
          <div className="footer-legal-links">
            <a href="#privacy">Privacy Policy</a>
            <a href="#terms">Terms of Service</a>
            <button
              className="cookie-optout-btn"
              onClick={() => alert('Cookie Preferences: Essential and analytical cookies are active.')}
            >
              Manage cookies or opt out
            </button>
          </div>
        </div>
      </div>
    </footer>
  );
};
