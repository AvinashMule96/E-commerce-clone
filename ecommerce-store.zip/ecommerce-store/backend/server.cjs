const http = require('http');
const fs = require('fs');
const path = require('path');
const url = require('url');

const authController = require('./controllers/authController.cjs');
const productsController = require('./controllers/productsController.cjs');
const cartController = require('./controllers/cartController.cjs');
const ordersController = require('./controllers/ordersController.cjs');
const supportController = require('./controllers/supportController.cjs');

const PORT = process.env.PORT || 3000;
const PUBLIC_DIR = path.join(__dirname, '..');

const MIME_TYPES = {
  '.html': 'text/html; charset=utf-8',
  '.js': 'application/javascript; charset=utf-8',
  '.jsx': 'application/javascript; charset=utf-8',
  '.css': 'text/css; charset=utf-8',
  '.json': 'application/json; charset=utf-8',
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.svg': 'image/svg+xml',
  '.ico': 'image/x-icon'
};

const sendJson = (res, statusCode, data) => {
  res.writeHead(statusCode, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': '*',
    'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type, Authorization'
  });
  res.end(JSON.stringify(data));
};

const parseBody = (req) => {
  return new Promise((resolve) => {
    let bodyStr = '';
    req.on('data', chunk => { bodyStr += chunk.toString(); });
    req.on('end', () => {
      try {
        resolve(bodyStr ? JSON.parse(bodyStr) : {});
      } catch (e) {
        resolve({});
      }
    });
  });
};

const server = http.createServer(async (req, res) => {
  if (req.method === 'OPTIONS') {
    res.writeHead(204, {
      'Access-Control-Allow-Origin': '*',
      'Access-Control-Allow-Methods': 'GET, POST, PUT, DELETE, OPTIONS',
      'Access-Control-Allow-Headers': 'Content-Type, Authorization'
    });
    res.end();
    return;
  }

  const parsedUrl = url.parse(req.url, true);
  const pathname = parsedUrl.pathname;
  const method = req.method;

  req.query = parsedUrl.query;
  req.body = (method === 'POST' || method === 'PUT') ? await parseBody(req) : {};
  req.params = {};

  res.status = function(code) {
    this.statusCode = code;
    return this;
  };
  res.json = function(data) {
    sendJson(this, this.statusCode || 200, data);
  };

  // REST API Routes
  if (pathname.startsWith('/api')) {
    // Auth
    if (pathname === '/api/auth/register' && method === 'POST') {
      return authController.register(req, res);
    }
    if (pathname === '/api/auth/login' && method === 'POST') {
      return authController.login(req, res);
    }
    if (pathname === '/api/auth/me' && method === 'GET') {
      return authController.getProfile(req, res);
    }

    // Categories & Products
    if (pathname === '/api/categories' && method === 'GET') {
      return productsController.getCategories(req, res);
    }
    if (pathname === '/api/products' && method === 'GET') {
      return productsController.getAllProducts(req, res);
    }
    if (pathname.startsWith('/api/products/') && pathname.endsWith('/reviews') && method === 'POST') {
      const parts = pathname.split('/');
      req.params.id = parts[3];
      return productsController.addProductReview(req, res);
    }
    if (pathname.startsWith('/api/products/') && method === 'GET') {
      const parts = pathname.split('/');
      req.params.id = parts[3];
      return productsController.getProductById(req, res);
    }

    // Cart
    if (pathname === '/api/cart' && method === 'GET') {
      return cartController.getCart(req, res);
    }
    if (pathname === '/api/cart/items' && method === 'POST') {
      return cartController.addItem(req, res);
    }
    if (pathname.startsWith('/api/cart/items/') && method === 'PUT') {
      const parts = pathname.split('/');
      req.params.id = parts[4];
      return cartController.updateQuantity(req, res);
    }
    if (pathname.startsWith('/api/cart/items/') && method === 'DELETE') {
      const parts = pathname.split('/');
      req.params.id = parts[4];
      return cartController.removeItem(req, res);
    }
    if (pathname === '/api/cart' && method === 'DELETE') {
      return cartController.clearCart(req, res);
    }
    if (pathname === '/api/cart/coupon' && method === 'POST') {
      return cartController.applyCoupon(req, res);
    }

    // Orders
    if (pathname === '/api/orders' && method === 'POST') {
      return ordersController.createOrder(req, res);
    }
    if (pathname === '/api/orders' && method === 'GET') {
      return ordersController.getAllOrders(req, res);
    }
    if (pathname.startsWith('/api/orders/') && method === 'GET') {
      const parts = pathname.split('/');
      req.params.id = parts[3];
      return ordersController.getOrderById(req, res);
    }

    // Support & Bookings
    if (pathname === '/api/bookings/slots' && method === 'GET') {
      return supportController.getTimeSlots(req, res);
    }
    if (pathname === '/api/bookings' && method === 'POST') {
      return supportController.createBooking(req, res);
    }
    if (pathname === '/api/support/contact' && method === 'POST') {
      return supportController.submitContact(req, res);
    }
    if (pathname === '/api/support/chat' && method === 'POST') {
      return supportController.chatBotReply(req, res);
    }

    return res.status(404).json({ success: false, error: `API route ${method} ${pathname} not found` });
  }

  // Static files & SPA routing
  let reqUrl = pathname;
  if (reqUrl === '/' || reqUrl === '') {
    reqUrl = '/standalone.html';
  }

  let filePath = path.join(PUBLIC_DIR, reqUrl);

  fs.stat(filePath, (err, stats) => {
    if (err || !stats.isFile()) {
      filePath = path.join(PUBLIC_DIR, 'standalone.html');
    }

    const ext = path.extname(filePath).toLowerCase();
    const contentType = MIME_TYPES[ext] || 'text/html; charset=utf-8';

    fs.readFile(filePath, (readErr, content) => {
      if (readErr) {
        res.writeHead(500, { 'Content-Type': 'text/plain' });
        res.end('500 Internal Server Error');
        return;
      }

      res.writeHead(200, {
        'Content-Type': contentType,
        'Access-Control-Allow-Origin': '*'
      });
      res.end(content);
    });
  });
});

server.listen(PORT, '0.0.0.0', () => {
  console.log(`\n======================================================`);
  console.log(`  VELOUR Fullstack Server (Backend API + UI) is LIVE!`);
  console.log(`  App UI:      http://localhost:${PORT}`);
  console.log(`  API Status:  http://localhost:${PORT}/api/categories`);
  console.log(`======================================================\n`);
});
