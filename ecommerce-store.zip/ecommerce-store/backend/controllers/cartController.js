const db = require('../models/db');

const calculateCartSummary = (cartItems, appliedCoupon) => {
  const subtotal = cartItems.reduce((acc, item) => acc + (Number(item.price) * item.quantity), 0);
  const tax = Number((subtotal * 0.06).toFixed(2));
  
  let discountAmount = 0;
  if (appliedCoupon?.discountPercent) {
    discountAmount = Number(((subtotal * appliedCoupon.discountPercent) / 100).toFixed(2));
  }

  let shipping = 0;
  if (subtotal > 0 && subtotal < 50 && !appliedCoupon?.freeShipping) {
    shipping = 5.00;
  }

  const total = Number((subtotal + tax + shipping - discountAmount).toFixed(2));

  return {
    itemCount: cartItems.reduce((acc, it) => acc + it.quantity, 0),
    subtotal: Number(subtotal.toFixed(2)),
    tax,
    shipping,
    discountAmount,
    appliedCoupon,
    total
  };
};

exports.getCart = (req, res) => {
  const data = db.read();
  const cartItems = data.cart || [];
  const appliedCoupon = data.appliedCoupon || null;
  const summary = calculateCartSummary(cartItems, appliedCoupon);

  return res.status(200).json({
    success: true,
    items: cartItems,
    summary
  });
};

exports.addItem = (req, res) => {
  const { productId, size = 'M', color = 'Standard', quantity = 1 } = req.body || {};

  if (!productId) {
    return res.status(400).json({ success: false, error: 'Product ID is required' });
  }

  const data = db.read();
  const product = data.products.find(p => p.id === productId);

  if (!product) {
    return res.status(404).json({ success: false, error: 'Product not found' });
  }

  const existingItemIndex = data.cart.findIndex(
    item => item.productId === productId && item.size === size && item.color === color
  );

  if (existingItemIndex > -1) {
    data.cart[existingItemIndex].quantity += Number(quantity);
  } else {
    data.cart.push({
      id: `cart-${productId}-${size}-${Date.now()}`,
      productId: product.id,
      name: product.name,
      price: product.price,
      size,
      color,
      quantity: Number(quantity) || 1,
      image: product.images?.[0] || product.image || ''
    });
  }

  db.write(data);
  const summary = calculateCartSummary(data.cart, data.appliedCoupon);

  return res.status(200).json({
    success: true,
    message: 'Item added to cart',
    items: data.cart,
    summary
  });
};

exports.updateQuantity = (req, res) => {
  const { id } = req.params;
  const { quantity } = req.body || {};

  const data = db.read();
  const itemIndex = data.cart.findIndex(item => item.id === id);

  if (itemIndex === -1) {
    return res.status(404).json({ success: false, error: 'Cart item not found' });
  }

  const newQty = parseInt(quantity, 10);
  if (newQty <= 0) {
    data.cart.splice(itemIndex, 1);
  } else {
    data.cart[itemIndex].quantity = newQty;
  }

  db.write(data);
  const summary = calculateCartSummary(data.cart, data.appliedCoupon);

  return res.status(200).json({
    success: true,
    items: data.cart,
    summary
  });
};

exports.removeItem = (req, res) => {
  const { id } = req.params;
  const data = db.read();

  data.cart = data.cart.filter(item => item.id !== id);
  db.write(data);
  const summary = calculateCartSummary(data.cart, data.appliedCoupon);

  return res.status(200).json({
    success: true,
    message: 'Item removed from cart',
    items: data.cart,
    summary
  });
};

exports.clearCart = (req, res) => {
  const data = db.read();
  data.cart = [];
  data.appliedCoupon = null;
  db.write(data);

  return res.status(200).json({
    success: true,
    message: 'Cart cleared',
    items: [],
    summary: calculateCartSummary([], null)
  });
};

exports.applyCoupon = (req, res) => {
  const { code } = req.body || {};
  if (!code) {
    return res.status(400).json({ success: false, error: 'Coupon code is required' });
  }

  const normalized = code.trim().toUpperCase();
  const data = db.read();

  if (normalized === 'SAVE10' || normalized === 'SUMMER10') {
    data.appliedCoupon = { code: normalized, discountPercent: 10, description: '10% Summer Discount' };
  } else if (normalized === 'FREESHIP') {
    data.appliedCoupon = { code: normalized, freeShipping: true, description: 'Free Shipping' };
  } else {
    return res.status(400).json({ success: false, error: 'Invalid coupon code. Try "SAVE10" or "SUMMER10".' });
  }

  db.write(data);
  const summary = calculateCartSummary(data.cart, data.appliedCoupon);

  return res.status(200).json({
    success: true,
    message: `Coupon ${normalized} applied!`,
    summary
  });
};
