const db = require('../models/db.cjs');

exports.getTimeSlots = (req, res) => {
  return res.status(200).json({
    success: true,
    month: 'June 2024',
    slots: [
      { id: 't1', time: '10:00 AM', available: true },
      { id: 't2', time: '11:30 AM', available: true },
      { id: 't3', time: '01:00 PM', available: true },
      { id: 't4', time: '02:30 PM', available: true },
      { id: 't5', time: '04:00 PM', available: true },
      { id: 't6', time: '05:30 PM', available: true }
    ]
  });
};

exports.createBooking = (req, res) => {
  const { date, time, customerName, email, service } = req.body || {};

  if (!date || !time) {
    return res.status(400).json({ success: false, error: 'Date and time are required' });
  }

  const data = db.read();
  const newBooking = {
    id: `BK-${Math.floor(1000 + Math.random() * 9000)}`,
    date,
    time,
    customerName: customerName || 'Alex Johnson',
    email: email || 'user@gmail.com',
    service: service || 'VIP Personal Styling Consultation',
    status: 'Confirmed',
    createdAt: new Date().toISOString()
  };

  if (!data.bookings) data.bookings = [];
  data.bookings.unshift(newBooking);
  db.write(data);

  return res.status(201).json({
    success: true,
    message: 'Styling appointment confirmed',
    booking: newBooking
  });
};

exports.submitContact = (req, res) => {
  const { name, email, message } = req.body || {};

  if (!name || !email || !message) {
    return res.status(400).json({ success: false, error: 'All fields are required' });
  }

  const data = db.read();
  const contactMsg = {
    id: `msg-${Date.now()}`,
    name: name.trim(),
    email: email.trim(),
    message: message.trim(),
    createdAt: new Date().toISOString()
  };

  if (!data.contactMessages) data.contactMessages = [];
  data.contactMessages.unshift(contactMsg);
  db.write(data);

  return res.status(201).json({
    success: true,
    message: 'Message sent successfully. Our support team will reply within 2 hours.'
  });
};

exports.chatBotReply = (req, res) => {
  const { message } = req.body || {};
  const text = (message || '').toLowerCase();

  let reply = "Thank you for reaching out! Our customer concierge team has noted your query and will update your dashboard promptly.";

  if (text.includes('return') || text.includes('refund')) {
    reply = "We offer a 30-day return policy! You can initiate a return or replacement directly from your My Orders tab.";
  } else if (text.includes('shipping') || text.includes('delivery')) {
    reply = "Orders placed today ship within 24 hours. Standard delivery is 2–4 business days with free shipping on orders above $50.";
  } else if (text.includes('order') || text.includes('ord-') || text.includes('track')) {
    reply = "Your order is confirmed and being prepared in our warehouse. You will receive an SMS and email with live courier tracking as soon as it departs.";
  }

  return res.status(200).json({
    success: true,
    reply,
    timestamp: new Date().toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })
  });
};
