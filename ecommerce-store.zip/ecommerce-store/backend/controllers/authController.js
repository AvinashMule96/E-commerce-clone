const db = require('../models/db');

exports.register = (req, res) => {
  const { name, email, password, phone } = req.body || {};

  if (!name || !email || !password) {
    return res.status(400).json({ success: false, error: 'Name, email, and password are required.' });
  }

  if (!email.includes('@')) {
    return res.status(400).json({ success: false, error: 'Please enter a valid email address.' });
  }

  if (password.length < 4) {
    return res.status(400).json({ success: false, error: 'Password must be at least 4 characters long.' });
  }

  const data = db.read();
  const existingUser = data.users.find(u => u.email.toLowerCase() === email.toLowerCase());

  if (existingUser) {
    return res.status(409).json({ success: false, error: 'An account with this email already exists.' });
  }

  const newUser = {
    id: `usr-${Date.now()}`,
    name: name.trim(),
    email: email.trim().toLowerCase(),
    phone: phone || '+1 (555) 234-5678',
    password: password, // In production this would be hashed with bcrypt
    role: 'customer',
    createdAt: new Date().toISOString()
  };

  data.users.push(newUser);
  db.write(data);

  // Return user without password
  const { password: _, ...userProfile } = newUser;
  return res.status(201).json({
    success: true,
    message: 'User registered successfully',
    user: userProfile,
    token: `tok_${userProfile.id}_${Date.now()}`
  });
};

exports.login = (req, res) => {
  const { email, password } = req.body || {};

  if (!email || !password) {
    return res.status(400).json({ success: false, error: 'Email/phone and password are required.' });
  }

  const data = db.read();
  const user = data.users.find(u => 
    (u.email.toLowerCase() === email.toLowerCase() || u.phone === email) && 
    u.password === password
  );

  // For seamless demo testing: if user not found, create a demo session user
  if (!user) {
    if (password.length >= 4) {
      const demoUser = {
        id: `usr-${Date.now()}`,
        name: email.includes('@') ? email.split('@')[0] : 'Demo Customer',
        email: email.includes('@') ? email.toLowerCase() : 'user@gmail.com',
        phone: !email.includes('@') ? email : '+1 (555) 234-5678',
        role: 'customer'
      };
      return res.status(200).json({
        success: true,
        message: 'Login successful',
        user: demoUser,
        token: `tok_${demoUser.id}_${Date.now()}`
      });
    }
    return res.status(401).json({ success: false, error: 'Invalid email or password.' });
  }

  const { password: _, ...userProfile } = user;
  return res.status(200).json({
    success: true,
    message: 'Login successful',
    user: userProfile,
    token: `tok_${userProfile.id}_${Date.now()}`
  });
};

exports.getProfile = (req, res) => {
  const data = db.read();
  const defaultUser = data.users[0] || {
    id: 'usr-1',
    name: 'Alex Johnson',
    email: 'user@gmail.com',
    phone: '+1 (555) 234-5678'
  };

  const { password: _, ...userProfile } = defaultUser;
  return res.status(200).json({ success: true, user: userProfile });
};
