const db = require('../models/db');

exports.createOrder = (req, res) => {
  const { customer, shippingAddress, paymentMethod, items, subtotal, tax, shipping, discount, total } = req.body || {};

  const data = db.read();
  const orderItems = items && items.length > 0 ? items : (data.cart || []);

  if (orderItems.length === 0) {
    return res.status(400).json({ success: false, error: 'Cannot place order with empty cart.' });
  }

  const orderId = `ORD-2026-${Math.floor(10000 + Math.random() * 90000)}`;
  const now = new Date();

  const formattedDate = now.toLocaleDateString('en-US', {
    year: 'numeric',
    month: 'long',
    day: 'numeric'
  });
  
  const formattedTime = now.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit'
  });

  const newOrder = {
    id: orderId,
    createdAt: now.toISOString(),
    dateString: `${formattedDate}, ${formattedTime}`,
    status: 'Confirmed',
    customer: {
      fullName: customer?.fullName || customer?.name || 'Alex Johnson',
      phone: customer?.phone || '+1 (555) 234-5678',
      email: customer?.email || 'user@gmail.com',
      address: shippingAddress?.address || customer?.address || '742 Evergreen Terrace',
      suite: shippingAddress?.suite || '',
      city: shippingAddress?.city || 'Springfield',
      state: shippingAddress?.state || 'CA',
      zipCode: shippingAddress?.zipCode || '97477'
    },
    payment: {
      method: paymentMethod?.type || paymentMethod || 'Credit / Debit Card',
      details: paymentMethod?.details || 'Card ending in •••• 4242',
      status: 'Paid'
    },
    items: orderItems.map(item => ({
      id: item.id || `item-${Date.now()}`,
      productId: item.productId,
      name: item.name,
      price: Number(item.price),
      size: item.size || 'M',
      color: item.color || 'Standard',
      quantity: Number(item.quantity) || 1,
      total: Number((item.price * (item.quantity || 1)).toFixed(2)),
      image: item.image
    })),
    pricing: {
      subtotal: Number(subtotal || orderItems.reduce((acc, it) => acc + (it.price * (it.quantity || 1)), 0)).toFixed(2),
      tax: Number(tax || 5.40).toFixed(2),
      shipping: Number(shipping || 0).toFixed(2),
      discount: Number(discount || 0).toFixed(2),
      total: Number(total || 95.38).toFixed(2)
    }
  };

  if (!data.orders) data.orders = [];
  data.orders.unshift(newOrder);

  // Clear active cart after order placement
  data.cart = [];
  data.appliedCoupon = null;

  db.write(data);

  return res.status(201).json({
    success: true,
    message: 'Order created successfully',
    order: newOrder
  });
};

exports.getAllOrders = (req, res) => {
  const data = db.read();
  return res.status(200).json({
    success: true,
    orders: data.orders || []
  });
};

exports.getOrderById = (req, res) => {
  const { id } = req.params;
  const data = db.read();
  const order = (data.orders || []).find(o => o.id === id);

  if (!order) {
    return res.status(404).json({ success: false, error: 'Order not found' });
  }

  return res.status(200).json({
    success: true,
    order
  });
};
