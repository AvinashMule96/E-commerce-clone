const db = require('../models/db');

exports.getCategories = (req, res) => {
  const data = db.read();
  return res.status(200).json({
    success: true,
    categories: data.categories || []
  });
};

exports.getAllProducts = (req, res) => {
  const data = db.read();
  let items = [...(data.products || [])];

  const { category, search, brand, minPrice, maxPrice, sort, page = 1, limit = 12 } = req.query || {};

  // Filter: Category
  if (category && category !== 'all') {
    if (category === 'deals') {
      items = items.filter(p => p.originalPrice && p.originalPrice > p.price);
    } else {
      items = items.filter(p => p.category.toLowerCase() === category.toLowerCase());
    }
  }

  // Filter: Search Keyword
  if (search && search.trim()) {
    const q = search.trim().toLowerCase();
    items = items.filter(p => 
      p.name.toLowerCase().includes(q) ||
      p.category.toLowerCase().includes(q) ||
      (p.brand && p.brand.toLowerCase().includes(q)) ||
      (p.shortDescription && p.shortDescription.toLowerCase().includes(q))
    );
  }

  // Filter: Brand
  if (brand) {
    const brandsList = Array.isArray(brand) ? brand : brand.split(',');
    items = items.filter(p => brandsList.includes(p.brand));
  }

  // Filter: Price Range
  if (minPrice) {
    items = items.filter(p => p.price >= Number(minPrice));
  }
  if (maxPrice) {
    items = items.filter(p => p.price <= Number(maxPrice));
  }

  // Sort
  if (sort === 'price-asc') {
    items.sort((a, b) => a.price - b.price);
  } else if (sort === 'price-desc') {
    items.sort((a, b) => b.price - a.price);
  } else if (sort === 'rating') {
    items.sort((a, b) => (b.rating || 0) - (a.rating || 0));
  } else if (sort === 'newest') {
    items.sort((a, b) => b.id.localeCompare(a.id));
  } else {
    // Popularity
    items.sort((a, b) => (b.reviewsCount || 0) - (a.reviewsCount || 0));
  }

  const total = items.length;
  const pageNum = parseInt(page, 10) || 1;
  const pageLimit = parseInt(limit, 10) || 12;
  const paginatedItems = items.slice((pageNum - 1) * pageLimit, pageNum * pageLimit);

  return res.status(200).json({
    success: true,
    total,
    page: pageNum,
    limit: pageLimit,
    totalPages: Math.ceil(total / pageLimit) || 1,
    products: paginatedItems
  });
};

exports.getProductById = (req, res) => {
  const { id } = req.params;
  const data = db.read();
  const product = data.products.find(p => p.id === id || p.slug === id);

  if (!product) {
    return res.status(404).json({ success: false, error: 'Product not found' });
  }

  return res.status(200).json({ success: true, product });
};

exports.addProductReview = (req, res) => {
  const { id } = req.params;
  const { name, rating, comment } = req.body || {};

  if (!name || !comment) {
    return res.status(400).json({ success: false, error: 'Name and comment are required' });
  }

  const data = db.read();
  const product = data.products.find(p => p.id === id || p.slug === id);

  if (!product) {
    return res.status(404).json({ success: false, error: 'Product not found' });
  }

  const newReview = {
    id: `rev-${Date.now()}`,
    name: name.trim(),
    rating: parseInt(rating, 10) || 5,
    comment: comment.trim(),
    date: new Date().toLocaleDateString('en-US', { year: 'numeric', month: 'long', day: 'numeric' })
  };

  if (!product.reviews) product.reviews = [];
  product.reviews.unshift(newReview);
  product.reviewsCount = (product.reviewsCount || 0) + 1;

  db.write(data);

  return res.status(201).json({
    success: true,
    message: 'Review added successfully',
    review: newReview,
    reviewsCount: product.reviewsCount
  });
};
