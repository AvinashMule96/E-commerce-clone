const fs = require('fs');
const path = require('path');

const DB_PATH = path.join(__dirname, '..', 'data', 'db.json');

const INITIAL_SEED_DATA = {
  users: [
    {
      id: 'usr-1',
      name: 'Alex Johnson',
      email: 'user@gmail.com',
      password: 'password123',
      phone: '+1 (555) 234-5678',
      role: 'customer',
      createdAt: '2024-06-01T10:00:00.000Z'
    }
  ],
  categories: [
    { id: 'men', name: 'Men', slug: 'men', count: 38, image: 'https://images.unsplash.com/photo-1617137984095-74e4e5e3613f?auto=format&fit=crop&w=600&q=80' },
    { id: 'women', name: 'Women', slug: 'women', count: 46, image: 'https://images.unsplash.com/photo-1483985988355-763728e1935b?auto=format&fit=crop&w=600&q=80' },
    { id: 'footwear', name: 'Footwear', slug: 'footwear', count: 24, image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=600&q=80' },
    { id: 'bags', name: 'Bags', slug: 'bags', count: 19, image: 'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=600&q=80' },
    { id: 'watches', name: 'Watches', slug: 'watches', count: 15, image: 'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=600&q=80' },
    { id: 'electronics', name: 'Electronics', slug: 'electronics', count: 22, image: 'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=600&q=80' },
    { id: 'deals', name: 'Deals', slug: 'deals', count: 28, image: 'https://images.unsplash.com/photo-1607082348824-0a96f2a4b9da?auto=format&fit=crop&w=600&q=80' }
  ],
  products: [
    {
      id: 'prod-1',
      name: 'Casual Cotton Shirt',
      slug: 'casual-cotton-shirt',
      category: 'men',
      subCategory: 'Shirts',
      brand: "Levi's",
      price: 29.99,
      originalPrice: 39.99,
      rating: 4.5,
      reviewsCount: 98,
      isBestSeller: true,
      inStock: true,
      images: [
        'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1602810318383-e386cc2a3ccf?auto=format&fit=crop&w=800&q=80'
      ],
      colors: [
        { name: 'Olive Green', hex: '#556b2f' },
        { name: 'Navy Blue', hex: '#1e3a8a' },
        { name: 'Onyx Black', hex: '#111827' }
      ],
      sizes: ['S', 'M', 'L', 'XL', 'XXL'],
      shortDescription: 'This casual cotton shirt is made from 100% premium cotton fabric. It is soft, breathable, and ideal for everyday wear.',
      features: [
        'Regular Fit tailored for effortless comfort',
        'Button-down collar with structured stitching',
        'Full sleeves with adjustable two-button cuffs'
      ]
    },
    {
      id: 'prod-2',
      name: 'Running Shoes',
      slug: 'running-shoes',
      category: 'footwear',
      subCategory: 'Sneakers',
      brand: 'Nike',
      price: 59.99,
      originalPrice: 79.99,
      rating: 4.8,
      reviewsCount: 142,
      isBestSeller: true,
      inStock: true,
      images: [
        'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80',
        'https://images.unsplash.com/photo-1608231387042-66d1773070a5?auto=format&fit=crop&w=800&q=80'
      ],
      colors: [
        { name: 'Black', hex: '#111827' },
        { name: 'Charcoal Gray', hex: '#4b5563' }
      ],
      sizes: ['7', '8', '9', '10', '11'],
      shortDescription: 'Ultralight performance running shoes designed for high energy return, breathable mesh ventilation, and all-day cushioning.'
    },
    {
      id: 'prod-3',
      name: 'Classic Slim Fit Denim',
      slug: 'classic-slim-fit-denim',
      category: 'men',
      subCategory: 'Jeans',
      brand: "Levi's",
      price: 49.99,
      originalPrice: 65.00,
      rating: 4.6,
      reviewsCount: 84,
      isBestSeller: true,
      inStock: true,
      images: [
        'https://images.unsplash.com/photo-1541099649105-f69ad21f3246?auto=format&fit=crop&w=800&q=80'
      ],
      colors: [{ name: 'Indigo Blue', hex: '#1e3a8a' }],
      sizes: ['30', '32', '34', '36'],
      shortDescription: 'Modern slim fit jeans crafted with comfort-stretch denim that moves naturally with your daily routine.'
    },
    {
      id: 'prod-4',
      name: 'Minimalist Leather Watch',
      slug: 'minimalist-leather-watch',
      category: 'watches',
      subCategory: 'Analog',
      brand: 'Fossil',
      price: 89.99,
      originalPrice: 120.00,
      rating: 4.9,
      reviewsCount: 116,
      isBestSeller: true,
      inStock: true,
      images: [
        'https://images.unsplash.com/photo-1524805444758-089113d48a6d?auto=format&fit=crop&w=800&q=80'
      ],
      colors: [{ name: 'Cognac Tan', hex: '#854d0e' }, { name: 'Black', hex: '#111827' }],
      sizes: ['40mm'],
      shortDescription: 'Sophisticated minimalist timepiece featuring a Japanese quartz movement, clean matte dial, and genuine Italian leather strap.'
    },
    {
      id: 'prod-5',
      name: 'Urban Canvas Backpack',
      slug: 'urban-canvas-backpack',
      category: 'bags',
      subCategory: 'Backpacks',
      brand: 'Puma',
      price: 45.00,
      originalPrice: 60.00,
      rating: 4.7,
      reviewsCount: 65,
      isBestSeller: true,
      inStock: true,
      images: [
        'https://images.unsplash.com/photo-1548036328-c9fa89d128fa?auto=format&fit=crop&w=800&q=80'
      ],
      colors: [{ name: 'Olive Green', hex: '#556b2f' }],
      sizes: ['20L'],
      shortDescription: 'Heavy-duty waxed canvas backpack equipped with padded laptop compartment, water-repellent finish, and ergonomic shoulder straps.'
    },
    {
      id: 'prod-6',
      name: 'Wireless ANC Headphones',
      slug: 'wireless-anc-headphones',
      category: 'electronics',
      subCategory: 'Audio',
      brand: 'Adidas',
      price: 99.99,
      originalPrice: 149.99,
      rating: 4.8,
      reviewsCount: 180,
      isBestSeller: true,
      inStock: true,
      images: [
        'https://images.unsplash.com/photo-1505740420928-5e560c06d30e?auto=format&fit=crop&w=800&q=80'
      ],
      colors: [{ name: 'Matte Black', hex: '#111827' }],
      sizes: ['Standard'],
      shortDescription: 'Studio-grade over-ear wireless headphones with hybrid Active Noise Cancellation and 40-hour battery life.'
    }
  ],
  cart: [
    {
      id: 'cart-1',
      productId: 'prod-1',
      name: 'Casual Cotton Shirt',
      price: 29.99,
      size: 'M',
      color: 'Olive Green',
      quantity: 1,
      image: 'https://images.unsplash.com/photo-1596755094514-f87e34085b2c?auto=format&fit=crop&w=800&q=80'
    },
    {
      id: 'cart-2',
      productId: 'prod-2',
      name: 'Running Shoes',
      price: 59.99,
      size: '9',
      color: 'Black',
      quantity: 1,
      image: 'https://images.unsplash.com/photo-1542291026-7eec264c27ff?auto=format&fit=crop&w=800&q=80'
    }
  ],
  appliedCoupon: null,
  orders: [],
  bookings: [],
  contactMessages: []
};

class Database {
  constructor() {
    this.ensureDbExists();
  }

  ensureDbExists() {
    const dir = path.dirname(DB_PATH);
    if (!fs.existsSync(dir)) {
      fs.mkdirSync(dir, { recursive: true });
    }
    if (!fs.existsSync(DB_PATH)) {
      fs.writeFileSync(DB_PATH, JSON.stringify(INITIAL_SEED_DATA, null, 2), 'utf-8');
    }
  }

  read() {
    try {
      this.ensureDbExists();
      const content = fs.readFileSync(DB_PATH, 'utf-8');
      return JSON.parse(content);
    } catch (err) {
      return INITIAL_SEED_DATA;
    }
  }

  write(data) {
    try {
      this.ensureDbExists();
      fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2), 'utf-8');
      return true;
    } catch (err) {
      console.error('Error writing to db.json', err);
      return false;
    }
  }
}

module.exports = new Database();
